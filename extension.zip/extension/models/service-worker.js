/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/papaparse/papaparse.min.js":
/*!*************************************************!*\
  !*** ./node_modules/papaparse/papaparse.min.js ***!
  \*************************************************/
/***/ (function(module, exports) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;/* @license
Papa Parse
v5.4.1
https://github.com/mholt/PapaParse
License: MIT
*/
!function(e,t){ true?!(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_FACTORY__ = (t),
		__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
		(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__)):0}(this,function s(){"use strict";var f="undefined"!=typeof self?self:"undefined"!=typeof window?window:void 0!==f?f:{};var n=!f.document&&!!f.postMessage,o=f.IS_PAPA_WORKER||!1,a={},u=0,b={parse:function(e,t){var r=(t=t||{}).dynamicTyping||!1;J(r)&&(t.dynamicTypingFunction=r,r={});if(t.dynamicTyping=r,t.transform=!!J(t.transform)&&t.transform,t.worker&&b.WORKERS_SUPPORTED){var i=function(){if(!b.WORKERS_SUPPORTED)return!1;var e=(r=f.URL||f.webkitURL||null,i=s.toString(),b.BLOB_URL||(b.BLOB_URL=r.createObjectURL(new Blob(["var global = (function() { if (typeof self !== 'undefined') { return self; } if (typeof window !== 'undefined') { return window; } if (typeof global !== 'undefined') { return global; } return {}; })(); global.IS_PAPA_WORKER=true; ","(",i,")();"],{type:"text/javascript"})))),t=new f.Worker(e);var r,i;return t.onmessage=_,t.id=u++,a[t.id]=t}();return i.userStep=t.step,i.userChunk=t.chunk,i.userComplete=t.complete,i.userError=t.error,t.step=J(t.step),t.chunk=J(t.chunk),t.complete=J(t.complete),t.error=J(t.error),delete t.worker,void i.postMessage({input:e,config:t,workerId:i.id})}var n=null;b.NODE_STREAM_INPUT,"string"==typeof e?(e=function(e){if(65279===e.charCodeAt(0))return e.slice(1);return e}(e),n=t.download?new l(t):new p(t)):!0===e.readable&&J(e.read)&&J(e.on)?n=new g(t):(f.File&&e instanceof File||e instanceof Object)&&(n=new c(t));return n.stream(e)},unparse:function(e,t){var n=!1,_=!0,m=",",y="\r\n",s='"',a=s+s,r=!1,i=null,o=!1;!function(){if("object"!=typeof t)return;"string"!=typeof t.delimiter||b.BAD_DELIMITERS.filter(function(e){return-1!==t.delimiter.indexOf(e)}).length||(m=t.delimiter);("boolean"==typeof t.quotes||"function"==typeof t.quotes||Array.isArray(t.quotes))&&(n=t.quotes);"boolean"!=typeof t.skipEmptyLines&&"string"!=typeof t.skipEmptyLines||(r=t.skipEmptyLines);"string"==typeof t.newline&&(y=t.newline);"string"==typeof t.quoteChar&&(s=t.quoteChar);"boolean"==typeof t.header&&(_=t.header);if(Array.isArray(t.columns)){if(0===t.columns.length)throw new Error("Option columns is empty");i=t.columns}void 0!==t.escapeChar&&(a=t.escapeChar+s);("boolean"==typeof t.escapeFormulae||t.escapeFormulae instanceof RegExp)&&(o=t.escapeFormulae instanceof RegExp?t.escapeFormulae:/^[=+\-@\t\r].*$/)}();var u=new RegExp(Q(s),"g");"string"==typeof e&&(e=JSON.parse(e));if(Array.isArray(e)){if(!e.length||Array.isArray(e[0]))return h(null,e,r);if("object"==typeof e[0])return h(i||Object.keys(e[0]),e,r)}else if("object"==typeof e)return"string"==typeof e.data&&(e.data=JSON.parse(e.data)),Array.isArray(e.data)&&(e.fields||(e.fields=e.meta&&e.meta.fields||i),e.fields||(e.fields=Array.isArray(e.data[0])?e.fields:"object"==typeof e.data[0]?Object.keys(e.data[0]):[]),Array.isArray(e.data[0])||"object"==typeof e.data[0]||(e.data=[e.data])),h(e.fields||[],e.data||[],r);throw new Error("Unable to serialize unrecognized input");function h(e,t,r){var i="";"string"==typeof e&&(e=JSON.parse(e)),"string"==typeof t&&(t=JSON.parse(t));var n=Array.isArray(e)&&0<e.length,s=!Array.isArray(t[0]);if(n&&_){for(var a=0;a<e.length;a++)0<a&&(i+=m),i+=v(e[a],a);0<t.length&&(i+=y)}for(var o=0;o<t.length;o++){var u=n?e.length:t[o].length,h=!1,f=n?0===Object.keys(t[o]).length:0===t[o].length;if(r&&!n&&(h="greedy"===r?""===t[o].join("").trim():1===t[o].length&&0===t[o][0].length),"greedy"===r&&n){for(var d=[],l=0;l<u;l++){var c=s?e[l]:l;d.push(t[o][c])}h=""===d.join("").trim()}if(!h){for(var p=0;p<u;p++){0<p&&!f&&(i+=m);var g=n&&s?e[p]:p;i+=v(t[o][g],p)}o<t.length-1&&(!r||0<u&&!f)&&(i+=y)}}return i}function v(e,t){if(null==e)return"";if(e.constructor===Date)return JSON.stringify(e).slice(1,25);var r=!1;o&&"string"==typeof e&&o.test(e)&&(e="'"+e,r=!0);var i=e.toString().replace(u,a);return(r=r||!0===n||"function"==typeof n&&n(e,t)||Array.isArray(n)&&n[t]||function(e,t){for(var r=0;r<t.length;r++)if(-1<e.indexOf(t[r]))return!0;return!1}(i,b.BAD_DELIMITERS)||-1<i.indexOf(m)||" "===i.charAt(0)||" "===i.charAt(i.length-1))?s+i+s:i}}};if(b.RECORD_SEP=String.fromCharCode(30),b.UNIT_SEP=String.fromCharCode(31),b.BYTE_ORDER_MARK="\ufeff",b.BAD_DELIMITERS=["\r","\n",'"',b.BYTE_ORDER_MARK],b.WORKERS_SUPPORTED=!n&&!!f.Worker,b.NODE_STREAM_INPUT=1,b.LocalChunkSize=10485760,b.RemoteChunkSize=5242880,b.DefaultDelimiter=",",b.Parser=E,b.ParserHandle=r,b.NetworkStreamer=l,b.FileStreamer=c,b.StringStreamer=p,b.ReadableStreamStreamer=g,f.jQuery){var d=f.jQuery;d.fn.parse=function(o){var r=o.config||{},u=[];return this.each(function(e){if(!("INPUT"===d(this).prop("tagName").toUpperCase()&&"file"===d(this).attr("type").toLowerCase()&&f.FileReader)||!this.files||0===this.files.length)return!0;for(var t=0;t<this.files.length;t++)u.push({file:this.files[t],inputElem:this,instanceConfig:d.extend({},r)})}),e(),this;function e(){if(0!==u.length){var e,t,r,i,n=u[0];if(J(o.before)){var s=o.before(n.file,n.inputElem);if("object"==typeof s){if("abort"===s.action)return e="AbortError",t=n.file,r=n.inputElem,i=s.reason,void(J(o.error)&&o.error({name:e},t,r,i));if("skip"===s.action)return void h();"object"==typeof s.config&&(n.instanceConfig=d.extend(n.instanceConfig,s.config))}else if("skip"===s)return void h()}var a=n.instanceConfig.complete;n.instanceConfig.complete=function(e){J(a)&&a(e,n.file,n.inputElem),h()},b.parse(n.file,n.instanceConfig)}else J(o.complete)&&o.complete()}function h(){u.splice(0,1),e()}}}function h(e){this._handle=null,this._finished=!1,this._completed=!1,this._halted=!1,this._input=null,this._baseIndex=0,this._partialLine="",this._rowCount=0,this._start=0,this._nextChunk=null,this.isFirstChunk=!0,this._completeResults={data:[],errors:[],meta:{}},function(e){var t=w(e);t.chunkSize=parseInt(t.chunkSize),e.step||e.chunk||(t.chunkSize=null);this._handle=new r(t),(this._handle.streamer=this)._config=t}.call(this,e),this.parseChunk=function(e,t){if(this.isFirstChunk&&J(this._config.beforeFirstChunk)){var r=this._config.beforeFirstChunk(e);void 0!==r&&(e=r)}this.isFirstChunk=!1,this._halted=!1;var i=this._partialLine+e;this._partialLine="";var n=this._handle.parse(i,this._baseIndex,!this._finished);if(!this._handle.paused()&&!this._handle.aborted()){var s=n.meta.cursor;this._finished||(this._partialLine=i.substring(s-this._baseIndex),this._baseIndex=s),n&&n.data&&(this._rowCount+=n.data.length);var a=this._finished||this._config.preview&&this._rowCount>=this._config.preview;if(o)f.postMessage({results:n,workerId:b.WORKER_ID,finished:a});else if(J(this._config.chunk)&&!t){if(this._config.chunk(n,this._handle),this._handle.paused()||this._handle.aborted())return void(this._halted=!0);n=void 0,this._completeResults=void 0}return this._config.step||this._config.chunk||(this._completeResults.data=this._completeResults.data.concat(n.data),this._completeResults.errors=this._completeResults.errors.concat(n.errors),this._completeResults.meta=n.meta),this._completed||!a||!J(this._config.complete)||n&&n.meta.aborted||(this._config.complete(this._completeResults,this._input),this._completed=!0),a||n&&n.meta.paused||this._nextChunk(),n}this._halted=!0},this._sendError=function(e){J(this._config.error)?this._config.error(e):o&&this._config.error&&f.postMessage({workerId:b.WORKER_ID,error:e,finished:!1})}}function l(e){var i;(e=e||{}).chunkSize||(e.chunkSize=b.RemoteChunkSize),h.call(this,e),this._nextChunk=n?function(){this._readChunk(),this._chunkLoaded()}:function(){this._readChunk()},this.stream=function(e){this._input=e,this._nextChunk()},this._readChunk=function(){if(this._finished)this._chunkLoaded();else{if(i=new XMLHttpRequest,this._config.withCredentials&&(i.withCredentials=this._config.withCredentials),n||(i.onload=v(this._chunkLoaded,this),i.onerror=v(this._chunkError,this)),i.open(this._config.downloadRequestBody?"POST":"GET",this._input,!n),this._config.downloadRequestHeaders){var e=this._config.downloadRequestHeaders;for(var t in e)i.setRequestHeader(t,e[t])}if(this._config.chunkSize){var r=this._start+this._config.chunkSize-1;i.setRequestHeader("Range","bytes="+this._start+"-"+r)}try{i.send(this._config.downloadRequestBody)}catch(e){this._chunkError(e.message)}n&&0===i.status&&this._chunkError()}},this._chunkLoaded=function(){4===i.readyState&&(i.status<200||400<=i.status?this._chunkError():(this._start+=this._config.chunkSize?this._config.chunkSize:i.responseText.length,this._finished=!this._config.chunkSize||this._start>=function(e){var t=e.getResponseHeader("Content-Range");if(null===t)return-1;return parseInt(t.substring(t.lastIndexOf("/")+1))}(i),this.parseChunk(i.responseText)))},this._chunkError=function(e){var t=i.statusText||e;this._sendError(new Error(t))}}function c(e){var i,n;(e=e||{}).chunkSize||(e.chunkSize=b.LocalChunkSize),h.call(this,e);var s="undefined"!=typeof FileReader;this.stream=function(e){this._input=e,n=e.slice||e.webkitSlice||e.mozSlice,s?((i=new FileReader).onload=v(this._chunkLoaded,this),i.onerror=v(this._chunkError,this)):i=new FileReaderSync,this._nextChunk()},this._nextChunk=function(){this._finished||this._config.preview&&!(this._rowCount<this._config.preview)||this._readChunk()},this._readChunk=function(){var e=this._input;if(this._config.chunkSize){var t=Math.min(this._start+this._config.chunkSize,this._input.size);e=n.call(e,this._start,t)}var r=i.readAsText(e,this._config.encoding);s||this._chunkLoaded({target:{result:r}})},this._chunkLoaded=function(e){this._start+=this._config.chunkSize,this._finished=!this._config.chunkSize||this._start>=this._input.size,this.parseChunk(e.target.result)},this._chunkError=function(){this._sendError(i.error)}}function p(e){var r;h.call(this,e=e||{}),this.stream=function(e){return r=e,this._nextChunk()},this._nextChunk=function(){if(!this._finished){var e,t=this._config.chunkSize;return t?(e=r.substring(0,t),r=r.substring(t)):(e=r,r=""),this._finished=!r,this.parseChunk(e)}}}function g(e){h.call(this,e=e||{});var t=[],r=!0,i=!1;this.pause=function(){h.prototype.pause.apply(this,arguments),this._input.pause()},this.resume=function(){h.prototype.resume.apply(this,arguments),this._input.resume()},this.stream=function(e){this._input=e,this._input.on("data",this._streamData),this._input.on("end",this._streamEnd),this._input.on("error",this._streamError)},this._checkIsFinished=function(){i&&1===t.length&&(this._finished=!0)},this._nextChunk=function(){this._checkIsFinished(),t.length?this.parseChunk(t.shift()):r=!0},this._streamData=v(function(e){try{t.push("string"==typeof e?e:e.toString(this._config.encoding)),r&&(r=!1,this._checkIsFinished(),this.parseChunk(t.shift()))}catch(e){this._streamError(e)}},this),this._streamError=v(function(e){this._streamCleanUp(),this._sendError(e)},this),this._streamEnd=v(function(){this._streamCleanUp(),i=!0,this._streamData("")},this),this._streamCleanUp=v(function(){this._input.removeListener("data",this._streamData),this._input.removeListener("end",this._streamEnd),this._input.removeListener("error",this._streamError)},this)}function r(m){var a,o,u,i=Math.pow(2,53),n=-i,s=/^\s*-?(\d+\.?|\.\d+|\d+\.\d+)([eE][-+]?\d+)?\s*$/,h=/^((\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d\.\d+([+-][0-2]\d:[0-5]\d|Z))|(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z))|(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z)))$/,t=this,r=0,f=0,d=!1,e=!1,l=[],c={data:[],errors:[],meta:{}};if(J(m.step)){var p=m.step;m.step=function(e){if(c=e,_())g();else{if(g(),0===c.data.length)return;r+=e.data.length,m.preview&&r>m.preview?o.abort():(c.data=c.data[0],p(c,t))}}}function y(e){return"greedy"===m.skipEmptyLines?""===e.join("").trim():1===e.length&&0===e[0].length}function g(){return c&&u&&(k("Delimiter","UndetectableDelimiter","Unable to auto-detect delimiting character; defaulted to '"+b.DefaultDelimiter+"'"),u=!1),m.skipEmptyLines&&(c.data=c.data.filter(function(e){return!y(e)})),_()&&function(){if(!c)return;function e(e,t){J(m.transformHeader)&&(e=m.transformHeader(e,t)),l.push(e)}if(Array.isArray(c.data[0])){for(var t=0;_()&&t<c.data.length;t++)c.data[t].forEach(e);c.data.splice(0,1)}else c.data.forEach(e)}(),function(){if(!c||!m.header&&!m.dynamicTyping&&!m.transform)return c;function e(e,t){var r,i=m.header?{}:[];for(r=0;r<e.length;r++){var n=r,s=e[r];m.header&&(n=r>=l.length?"__parsed_extra":l[r]),m.transform&&(s=m.transform(s,n)),s=v(n,s),"__parsed_extra"===n?(i[n]=i[n]||[],i[n].push(s)):i[n]=s}return m.header&&(r>l.length?k("FieldMismatch","TooManyFields","Too many fields: expected "+l.length+" fields but parsed "+r,f+t):r<l.length&&k("FieldMismatch","TooFewFields","Too few fields: expected "+l.length+" fields but parsed "+r,f+t)),i}var t=1;!c.data.length||Array.isArray(c.data[0])?(c.data=c.data.map(e),t=c.data.length):c.data=e(c.data,0);m.header&&c.meta&&(c.meta.fields=l);return f+=t,c}()}function _(){return m.header&&0===l.length}function v(e,t){return r=e,m.dynamicTypingFunction&&void 0===m.dynamicTyping[r]&&(m.dynamicTyping[r]=m.dynamicTypingFunction(r)),!0===(m.dynamicTyping[r]||m.dynamicTyping)?"true"===t||"TRUE"===t||"false"!==t&&"FALSE"!==t&&(function(e){if(s.test(e)){var t=parseFloat(e);if(n<t&&t<i)return!0}return!1}(t)?parseFloat(t):h.test(t)?new Date(t):""===t?null:t):t;var r}function k(e,t,r,i){var n={type:e,code:t,message:r};void 0!==i&&(n.row=i),c.errors.push(n)}this.parse=function(e,t,r){var i=m.quoteChar||'"';if(m.newline||(m.newline=function(e,t){e=e.substring(0,1048576);var r=new RegExp(Q(t)+"([^]*?)"+Q(t),"gm"),i=(e=e.replace(r,"")).split("\r"),n=e.split("\n"),s=1<n.length&&n[0].length<i[0].length;if(1===i.length||s)return"\n";for(var a=0,o=0;o<i.length;o++)"\n"===i[o][0]&&a++;return a>=i.length/2?"\r\n":"\r"}(e,i)),u=!1,m.delimiter)J(m.delimiter)&&(m.delimiter=m.delimiter(e),c.meta.delimiter=m.delimiter);else{var n=function(e,t,r,i,n){var s,a,o,u;n=n||[",","\t","|",";",b.RECORD_SEP,b.UNIT_SEP];for(var h=0;h<n.length;h++){var f=n[h],d=0,l=0,c=0;o=void 0;for(var p=new E({comments:i,delimiter:f,newline:t,preview:10}).parse(e),g=0;g<p.data.length;g++)if(r&&y(p.data[g]))c++;else{var _=p.data[g].length;l+=_,void 0!==o?0<_&&(d+=Math.abs(_-o),o=_):o=_}0<p.data.length&&(l/=p.data.length-c),(void 0===a||d<=a)&&(void 0===u||u<l)&&1.99<l&&(a=d,s=f,u=l)}return{successful:!!(m.delimiter=s),bestDelimiter:s}}(e,m.newline,m.skipEmptyLines,m.comments,m.delimitersToGuess);n.successful?m.delimiter=n.bestDelimiter:(u=!0,m.delimiter=b.DefaultDelimiter),c.meta.delimiter=m.delimiter}var s=w(m);return m.preview&&m.header&&s.preview++,a=e,o=new E(s),c=o.parse(a,t,r),g(),d?{meta:{paused:!0}}:c||{meta:{paused:!1}}},this.paused=function(){return d},this.pause=function(){d=!0,o.abort(),a=J(m.chunk)?"":a.substring(o.getCharIndex())},this.resume=function(){t.streamer._halted?(d=!1,t.streamer.parseChunk(a,!0)):setTimeout(t.resume,3)},this.aborted=function(){return e},this.abort=function(){e=!0,o.abort(),c.meta.aborted=!0,J(m.complete)&&m.complete(c),a=""}}function Q(e){return e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function E(j){var z,M=(j=j||{}).delimiter,P=j.newline,U=j.comments,q=j.step,N=j.preview,B=j.fastMode,K=z=void 0===j.quoteChar||null===j.quoteChar?'"':j.quoteChar;if(void 0!==j.escapeChar&&(K=j.escapeChar),("string"!=typeof M||-1<b.BAD_DELIMITERS.indexOf(M))&&(M=","),U===M)throw new Error("Comment character same as delimiter");!0===U?U="#":("string"!=typeof U||-1<b.BAD_DELIMITERS.indexOf(U))&&(U=!1),"\n"!==P&&"\r"!==P&&"\r\n"!==P&&(P="\n");var W=0,H=!1;this.parse=function(i,t,r){if("string"!=typeof i)throw new Error("Input must be a string");var n=i.length,e=M.length,s=P.length,a=U.length,o=J(q),u=[],h=[],f=[],d=W=0;if(!i)return L();if(j.header&&!t){var l=i.split(P)[0].split(M),c=[],p={},g=!1;for(var _ in l){var m=l[_];J(j.transformHeader)&&(m=j.transformHeader(m,_));var y=m,v=p[m]||0;for(0<v&&(g=!0,y=m+"_"+v),p[m]=v+1;c.includes(y);)y=y+"_"+v;c.push(y)}if(g){var k=i.split(P);k[0]=c.join(M),i=k.join(P)}}if(B||!1!==B&&-1===i.indexOf(z)){for(var b=i.split(P),E=0;E<b.length;E++){if(f=b[E],W+=f.length,E!==b.length-1)W+=P.length;else if(r)return L();if(!U||f.substring(0,a)!==U){if(o){if(u=[],I(f.split(M)),F(),H)return L()}else I(f.split(M));if(N&&N<=E)return u=u.slice(0,N),L(!0)}}return L()}for(var w=i.indexOf(M,W),R=i.indexOf(P,W),C=new RegExp(Q(K)+Q(z),"g"),S=i.indexOf(z,W);;)if(i[W]!==z)if(U&&0===f.length&&i.substring(W,W+a)===U){if(-1===R)return L();W=R+s,R=i.indexOf(P,W),w=i.indexOf(M,W)}else if(-1!==w&&(w<R||-1===R))f.push(i.substring(W,w)),W=w+e,w=i.indexOf(M,W);else{if(-1===R)break;if(f.push(i.substring(W,R)),D(R+s),o&&(F(),H))return L();if(N&&u.length>=N)return L(!0)}else for(S=W,W++;;){if(-1===(S=i.indexOf(z,S+1)))return r||h.push({type:"Quotes",code:"MissingQuotes",message:"Quoted field unterminated",row:u.length,index:W}),T();if(S===n-1)return T(i.substring(W,S).replace(C,z));if(z!==K||i[S+1]!==K){if(z===K||0===S||i[S-1]!==K){-1!==w&&w<S+1&&(w=i.indexOf(M,S+1)),-1!==R&&R<S+1&&(R=i.indexOf(P,S+1));var O=A(-1===R?w:Math.min(w,R));if(i.substr(S+1+O,e)===M){f.push(i.substring(W,S).replace(C,z)),i[W=S+1+O+e]!==z&&(S=i.indexOf(z,W)),w=i.indexOf(M,W),R=i.indexOf(P,W);break}var x=A(R);if(i.substring(S+1+x,S+1+x+s)===P){if(f.push(i.substring(W,S).replace(C,z)),D(S+1+x+s),w=i.indexOf(M,W),S=i.indexOf(z,W),o&&(F(),H))return L();if(N&&u.length>=N)return L(!0);break}h.push({type:"Quotes",code:"InvalidQuotes",message:"Trailing quote on quoted field is malformed",row:u.length,index:W}),S++}}else S++}return T();function I(e){u.push(e),d=W}function A(e){var t=0;if(-1!==e){var r=i.substring(S+1,e);r&&""===r.trim()&&(t=r.length)}return t}function T(e){return r||(void 0===e&&(e=i.substring(W)),f.push(e),W=n,I(f),o&&F()),L()}function D(e){W=e,I(f),f=[],R=i.indexOf(P,W)}function L(e){return{data:u,errors:h,meta:{delimiter:M,linebreak:P,aborted:H,truncated:!!e,cursor:d+(t||0)}}}function F(){q(L()),u=[],h=[]}},this.abort=function(){H=!0},this.getCharIndex=function(){return W}}function _(e){var t=e.data,r=a[t.workerId],i=!1;if(t.error)r.userError(t.error,t.file);else if(t.results&&t.results.data){var n={abort:function(){i=!0,m(t.workerId,{data:[],errors:[],meta:{aborted:!0}})},pause:y,resume:y};if(J(r.userStep)){for(var s=0;s<t.results.data.length&&(r.userStep({data:t.results.data[s],errors:t.results.errors,meta:t.results.meta},n),!i);s++);delete t.results}else J(r.userChunk)&&(r.userChunk(t.results,n,t.file),delete t.results)}t.finished&&!i&&m(t.workerId,t.results)}function m(e,t){var r=a[e];J(r.userComplete)&&r.userComplete(t),r.terminate(),delete a[e]}function y(){throw new Error("Not implemented.")}function w(e){if("object"!=typeof e||null===e)return e;var t=Array.isArray(e)?[]:{};for(var r in e)t[r]=w(e[r]);return t}function v(e,t){return function(){e.apply(t,arguments)}}function J(e){return"function"==typeof e}return o&&(f.onmessage=function(e){var t=e.data;void 0===b.WORKER_ID&&t&&(b.WORKER_ID=t.workerId);if("string"==typeof t.input)f.postMessage({workerId:b.WORKER_ID,results:b.parse(t.input,t.config),finished:!0});else if(f.File&&t.input instanceof File||t.input instanceof Object){var r=b.parse(t.input,t.config);r&&f.postMessage({workerId:b.WORKER_ID,results:r,finished:!0})}}),(l.prototype=Object.create(h.prototype)).constructor=l,(c.prototype=Object.create(h.prototype)).constructor=c,(p.prototype=Object.create(p.prototype)).constructor=p,(g.prototype=Object.create(h.prototype)).constructor=g,b});

/***/ }),

/***/ "./src/extensioncommon.ts":
/*!********************************!*\
  !*** ./src/extensioncommon.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AnalyzerExtensionCommon: () => (/* binding */ AnalyzerExtensionCommon)
/* harmony export */ });
class AnalyzerExtensionCommon {
    constructor(chrome) {
        this.promptUrl = `https://us-central1-promptplusai.cloudfunctions.net/lobbyApi/session/external/message`;
        this.cloudWriteUrl = `https://us-central1-promptplusai.cloudfunctions.net/lobbyApi/session/external/cloudwrite`;
        this.debouncedInputTimeouts = {};
        this.lastSeenContextMenuSettings = {};
        this.defaultScrapedLengthCharacterLimit = 20000;
        this.chrome = chrome;
    }
    async getEmbeddingCharacterLimit() {
        let limit = await this.getStorageField('scrapedLengthCharacterLimit');
        limit = Number(limit);
        if (!limit)
            limit = this.defaultScrapedLengthCharacterLimit;
        return limit;
    }
    generatePagination(totalItems, currentEntryIndex, itemsPerPage, currentPageIndex) {
        const totalPages = Math.ceil(totalItems / itemsPerPage);
        let paginationHtml = '';
        paginationHtml = '<ul class="pagination pagination-sm mb-0">';
        paginationHtml += `
    <li class="page-item ${currentPageIndex === 0 || totalPages === 0 ? 'buttondisabled' : ''}">
        <a class="page-link" href="#" aria-label="Previous" data-entryindex="-1">
            <span aria-hidden="true">&laquo;</span>
        </a>
    </li>
    <li class="page-item ${currentEntryIndex === 0 ? 'buttondisabled' : ''}">
      <a class="page-link" href="#" data-entryindex="-10">
          <span aria-hidden="true">
           &#x2190; 
          </span>
      </a>
    </li>`;
        const startIndex = currentPageIndex * itemsPerPage;
        const endIndex = Math.min((currentPageIndex + 1) * itemsPerPage, totalItems);
        for (let i = startIndex; i < endIndex; i++) {
            paginationHtml += `<li class="page-item ${currentEntryIndex === i ? 'selected' : ''}">
        <a class="page-link" href="#" data-entryindex="${i}">
            <span aria-hidden="true">${i + 1}</span>
        </a>
    </li>`;
        }
        paginationHtml += `
    <li class="page-item ${currentEntryIndex === totalItems - 1 ? 'buttondisabled' : ''}">
      <a class="page-link" href="#" data-entryindex="-20">
        <span aria-hidden="true">&#x2192;</span>
      </a>
    </li>
    <li class="page-item ${currentPageIndex === totalPages - 1 || totalPages === 0 ? 'buttondisabled' : ''}">
        <a class="page-link" href="#" aria-label="Next" data-entryindex="-2">
            <span aria-hidden="true">&raquo;</span>
        </a>
    </li>`;
        paginationHtml += `<li class="page-item count">
               <span>${totalItems}<br>items</li>`;
        paginationHtml += '</ul>';
        return paginationHtml;
    }
    handlePaginationClick(newIndex, totalItems, selectedIndex, itemsPerPage, pageIndex) {
        if (newIndex === -1) {
            pageIndex = Math.max(pageIndex - 1, 0);
            if (selectedIndex < pageIndex * itemsPerPage) {
                selectedIndex = pageIndex * itemsPerPage;
            }
            else if (selectedIndex > (pageIndex + 1) * itemsPerPage - 1) {
                selectedIndex = pageIndex * itemsPerPage;
            }
        }
        else if (newIndex === -2) {
            pageIndex = Math.min(pageIndex + 1, Math.ceil(totalItems / itemsPerPage) - 1);
            if (selectedIndex < pageIndex * itemsPerPage) {
                selectedIndex = pageIndex * itemsPerPage;
            }
            else if (selectedIndex > (pageIndex + 1) * itemsPerPage - 1) {
                selectedIndex = pageIndex * itemsPerPage;
            }
        }
        else if (newIndex === -10) {
            selectedIndex -= 1;
            pageIndex = Math.floor(selectedIndex / itemsPerPage);
        }
        else if (newIndex === -20) {
            selectedIndex += 1;
            if (selectedIndex > totalItems - 1)
                selectedIndex = totalItems - 1;
            if (selectedIndex < 0)
                selectedIndex = 0;
            pageIndex = Math.floor(selectedIndex / itemsPerPage);
        }
        else {
            selectedIndex = newIndex;
            pageIndex = Math.floor(selectedIndex / itemsPerPage);
        }
        return {
            selectedIndex,
            pageIndex,
        };
    }
    async processPromptUsingUnacogAPI(message) {
        let apiToken = await this.chrome.storage.local.get('apiToken');
        apiToken = apiToken.apiToken || '';
        let sessionId = await this.chrome.storage.local.get('sessionId');
        sessionId = sessionId.sessionId || '';
        let resultMessage = 'unknown error';
        let promptResult = {};
        let error = true;
        const body = {
            message,
            apiToken,
            sessionId,
            disableEmbedding: true,
        };
        try {
            const fetchResults = await fetch(this.promptUrl, {
                method: "POST",
                mode: "cors",
                cache: "no-cache",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(body),
            });
            promptResult = await fetchResults.json();
            if (!promptResult.success) {
                console.log("error", promptResult);
                resultMessage = promptResult.errorMessage;
            }
            else {
            }
            if (promptResult.assist) {
                if (promptResult.assist.error) {
                    resultMessage = promptResult.assist.error.message;
                }
                else if (promptResult.assist.assist.error) {
                    resultMessage = promptResult.assist.assist.error.message;
                }
                else {
                    resultMessage = promptResult.assist.assist.choices["0"].message.content;
                    error = false;
                }
            }
        }
        catch (err) {
            console.log("error", err);
            resultMessage = err.message;
            error = err;
        }
        return {
            resultMessage,
            originalPrompt: message,
            promptResult,
            error,
        };
    }
    async writeCloudDataUsingUnacogAPI(fileName, fileData, mimeType = "", fileExt = "") {
        let apiToken = await this.chrome.storage.local.get('apiToken');
        apiToken = apiToken.apiToken || '';
        let sessionId = await this.chrome.storage.local.get('sessionId');
        sessionId = sessionId.sessionId || '';
        const body = {
            fileName,
            apiToken,
            sessionId,
            fileData,
            mimeType,
            fileExt,
        };
        try {
            const fetchResults = await fetch(this.cloudWriteUrl, {
                method: "POST",
                mode: "cors",
                cache: "no-cache",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(body),
            });
            const cloudWriteResult = await fetchResults.json();
            if (!cloudWriteResult.success) {
                return cloudWriteResult;
            }
            const encodedFragment = encodeURIComponent(cloudWriteResult.storagePath);
            const publicStorageUrlPath = `https://firebasestorage.googleapis.com/v0/b/promptplusai.appspot.com/o/${encodedFragment}?alt=media`;
            return {
                success: true,
                publicStorageUrlPath,
            };
        }
        catch (err) {
            return {
                success: false,
                error: err,
            };
        }
    }
    processRawResultstoCompact(analysisResults) {
        let compactData = [];
        analysisResults.forEach((urlResult) => {
            let compactResult = {};
            compactResult.url = urlResult.url;
            compactResult.title = urlResult.title;
            const results = urlResult.results;
            if (results) {
                results.forEach((metricResult) => {
                    const fieldName = metricResult.prompt.name + "_" + metricResult.prompt.setName;
                    if (metricResult.prompt.metricType === "score 0 - 10") {
                        let metric = 0;
                        try {
                            let json = JSON.parse(metricResult.result.resultMessage);
                            metric = json.contentRating;
                        }
                        catch (e) {
                            metric = -1;
                        }
                        compactResult[fieldName] = metric;
                    }
                    else {
                        compactResult[fieldName] = metricResult.result.resultMessage;
                    }
                });
            }
            else {
                compactResult["No Results"] = "No Results";
            }
            compactData.push(compactResult);
        });
        if (compactData.length > 0) {
            const firstRow = compactData[0];
            const allFields = {};
            compactData.forEach((row) => {
                Object.keys(row).forEach((field) => {
                    allFields[field] = true;
                });
            });
            const fieldNames = Object.keys(allFields);
            fieldNames.forEach((fieldName) => {
                if (!firstRow[fieldName]) {
                    firstRow[fieldName] = "";
                }
            });
        }
        return compactData;
    }
    async setBulkRunning() {
        let bulk_running = await this.chrome.storage.local.get('bulk_running');
        if (bulk_running && bulk_running.bulk_running) {
            return true;
        }
        await this.chrome.storage.local.set({
            bulk_running: true,
        });
        return false;
    }
    prepDataForHistoryRender(entry, historyIndex) {
        let usageCreditTotal = 0;
        let resultHistory = entry.result;
        if (!resultHistory)
            resultHistory = entry.results[0];
        let noError = true;
        let errorMessage = "";
        if (entry.results.length > 0) {
            entry.results.forEach((result) => {
                if (result.result.error) {
                    noError = false;
                    errorMessage = result?.result?.promptResult?.assist?.error;
                }
            });
            if (!noError) {
                return {
                    html: `<div class="history_error_message flex-1 text-center">${errorMessage}</div>`,
                    usageCreditTotal,
                };
            }
        }
        let allResults = entry.results;
        let setBasedResults = {};
        allResults.forEach((result) => {
            if (!setBasedResults[result.prompt.setName]) {
                setBasedResults[result.prompt.setName] = [];
            }
            setBasedResults[result.prompt.setName].push(result);
        });
        const setNamesArray = Object.keys(setBasedResults);
        return {
            setNamesArray,
            setBasedResults,
            allResults,
        };
    }
    static _formatAMPM(date) {
        let hours = date.getHours();
        let minutes = date.getMinutes();
        const ampm = hours >= 12 ? "pm" : "am";
        hours = hours % 12;
        hours = hours ? hours : 12; // the hour '0' should be '12'
        minutes = minutes < 10 ? "0" + minutes : minutes;
        return hours + ":" + minutes + " " + ampm;
    }
    static showGmailStyleDate(ISOdate, amFormat = false) {
        let date = new Date(ISOdate);
        if (Date.now() - date.getTime() < 24 * 60 * 60 * 1000) {
            if (amFormat)
                return this._formatAMPM(date);
            let result = this._formatAMPM(date);
            return result;
        }
        return date.toLocaleDateString("en-us", {
            month: "short",
            day: "numeric",
        });
    }
    static timeSince(date, showSeconds = false) {
        let seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
        seconds = Math.max(seconds, 0);
        let interval = seconds / 31536000;
        if (interval > 1)
            return Math.floor(interval) + ` yrs ago`;
        interval = seconds / 2592000;
        if (interval > 1)
            return Math.floor(interval) + ` months ago`;
        interval = seconds / 86400;
        if (interval > 1)
            return Math.floor(interval) + ` days ago`;
        interval = seconds / 3600;
        if (interval > 1)
            return Math.floor(interval) + ` hrs ago`;
        if (showSeconds)
            return Math.floor(seconds) + " s";
        interval = seconds / 60;
        if (interval > 1)
            return Math.floor(interval) + ` mins ago`;
        return "now";
    }
    static updateTimeSince(container) {
        const elements = container.querySelectorAll(".time_since");
        elements.forEach((ctl) => {
            const timeStyle = ctl.dataset.timestyle;
            const isoTime = ctl.dataset.timesince;
            const showSeconds = ctl.dataset.showseconds;
            let dateDisplay;
            if (timeStyle === "gmail") {
                dateDisplay = AnalyzerExtensionCommon.showGmailStyleDate(new Date(isoTime));
            }
            else {
                dateDisplay = AnalyzerExtensionCommon.timeSince(new Date(isoTime), (showSeconds === "1"));
            }
            ctl.innerText = dateDisplay;
        });
    }
    async toggleExentionPage(url) {
        const [extensionTab] = await this.chrome.tabs.query({
            url: `chrome-extension://${this.chrome.runtime.id}/main.html`,
            lastFocusedWindow: true,
        });
        const urlHashtag = url.split("#")[1] || "";
        if (extensionTab) {
            await this.chrome.tabs.update(extensionTab.id, {
                active: true,
                url: `chrome-extension://${this.chrome.runtime.id}/main.html#${urlHashtag}`
            });
        }
        else {
            await this.chrome.tabs.create({
                url
            });
        }
    }
    async toggleSidePanel(currentTab = null) {
        const lastPanelToggleDate = new Date().toISOString();
        if (currentTab) {
            this.chrome.sidePanel.open({ tabId: currentTab.id });
        }
        else {
            [currentTab] = await this.chrome.tabs.query({
                active: true,
                lastFocusedWindow: true,
            });
            this.chrome.sidePanel.open({ tabId: currentTab.id });
        }
        await this.chrome.storage.local.set({
            lastPanelToggleDate,
            lastPanelToggleWindowId: currentTab.windowId,
        });
    }
    async updateSessionKeyStatus() {
        let sessionId = await this.chrome.storage.local.get('sessionId');
        sessionId = sessionId?.sessionId || "";
        let apiToken = await this.chrome.storage.local.get('apiToken');
        apiToken = apiToken?.apiToken || "";
        if (apiToken && sessionId) {
            document.body.classList.add("session_key_set");
            document.body.classList.remove("no_session_key_set");
        }
        else {
            document.body.classList.remove("session_key_set");
            document.body.classList.add("no_session_key_set");
        }
    }
    async getFieldFromStorage(domInput, storageKey, defaultStorageKey = "") {
        clearTimeout(this.debouncedInputTimeouts[storageKey]);
        const getFieldValue = async () => {
            let value = await this.getStorageField(storageKey);
            if (!value && defaultStorageKey)
                value = await this.getStorageField(defaultStorageKey);
            return value;
        };
        const value = await getFieldValue();
        if (value === domInput.value)
            return;
        if (!this.debouncedInputTimeouts[storageKey] && !domInput.value && value) {
            domInput.value = value;
        }
        this.debouncedInputTimeouts[storageKey] = setTimeout(async () => {
            const value = await getFieldValue();
            if (domInput.value !== value)
                domInput.value = value;
        }, 500);
    }
    async getStorageField(field) {
        let value = await this.chrome.storage.local.get(field);
        value = value[field] || '';
        return value;
    }
    async setFieldToStorage(domInput, storageKey) {
        let value = domInput.value;
        await this.chrome.storage.local.set({ [storageKey]: value });
    }
    async enabledBrowserScrapePermissions() {
        // Permissions must be requested from inside a user gesture, like a button's
        // click handler.
        await this.chrome.permissions.request({
            permissions: ["tabs"],
            origins: ["https://*/*",
                "http://*/*"]
        }, (granted) => {
            if (!granted) {
                alert("Browser scraping permission denied. You can enable it from the extension settings page");
            }
        });
    }
    static processOptions(options) {
        const opts = options.split("||");
        const optionsMap = {};
        opts.forEach((opt) => {
            const pieces = opt.trim().split("=");
            const key = pieces[0].trim();
            if (key !== "") {
                let value = "";
                if (pieces.length > 1)
                    value = pieces.slice(1).join("=").trim();
                optionsMap[key] = value;
            }
        });
        return optionsMap;
    }
    async updateBrowserContextMenus() {
        const hideAnalyzeInPageContextMenu = await this.getStorageField('hideAnalyzeInPageContextMenu');
        const showQueryInPageContextMenu = await this.getStorageField('showQueryInPageContextMenu');
        const hideAnalyzeInSelectionContextMenu = await this.getStorageField('hideAnalyzeInSelectionContextMenu');
        const showQueryInSelectionContextMenu = await this.getStorageField('showQueryInSelectionContextMenu');
        let updateContextMenu = false;
        if (this.lastSeenContextMenuSettings.hideAnalyzeInSelectionContextMenu !== hideAnalyzeInSelectionContextMenu) {
            this.lastSeenContextMenuSettings.hideAnalyzeInSelectionContextMenu = hideAnalyzeInSelectionContextMenu;
            updateContextMenu = true;
        }
        if (this.lastSeenContextMenuSettings.hideAnalyzeInPageContextMenu !== hideAnalyzeInPageContextMenu) {
            this.lastSeenContextMenuSettings.hideAnalyzeInPageContextMenu = hideAnalyzeInPageContextMenu;
            updateContextMenu = true;
        }
        if (this.lastSeenContextMenuSettings.showQueryInSelectionContextMenu !== showQueryInSelectionContextMenu) {
            this.lastSeenContextMenuSettings.showQueryInSelectionContextMenu = showQueryInSelectionContextMenu;
            updateContextMenu = true;
        }
        if (this.lastSeenContextMenuSettings.showQueryInPageContextMenu !== showQueryInPageContextMenu) {
            this.lastSeenContextMenuSettings.showQueryInPageContextMenu = showQueryInPageContextMenu;
            updateContextMenu = true;
        }
        if (!updateContextMenu)
            return;
        await this.chrome.contextMenus.removeAll();
        if (!hideAnalyzeInSelectionContextMenu) {
            this.chrome.contextMenus.create({
                id: 'hideAnalyzeInSelectionContextMenu',
                title: 'Analyze selection',
                type: 'normal',
                contexts: ['selection']
            });
        }
        if (!hideAnalyzeInPageContextMenu) {
            this.chrome.contextMenus.create({
                id: 'hideAnalyzeInPageContextMenu',
                title: 'Analyze page',
                type: 'normal',
                contexts: ['page']
            });
        }
        if (showQueryInSelectionContextMenu) {
            this.chrome.contextMenus.create({
                id: 'showQueryInSelectionContextMenu',
                title: 'Semantic query Selection',
                type: 'normal',
                contexts: ['selection']
            });
        }
        if (showQueryInPageContextMenu) {
            this.chrome.contextMenus.create({
                id: 'showQueryInPageContextMenu',
                title: 'Semantic query page',
                type: 'normal',
                contexts: ['page']
            });
        }
    }
}


/***/ }),

/***/ "./src/metriccommon.ts":
/*!*****************************!*\
  !*** ./src/metriccommon.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MetricCommon: () => (/* binding */ MetricCommon)
/* harmony export */ });
/* harmony import */ var _extensioncommon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./extensioncommon */ "./src/extensioncommon.ts");
/* harmony import */ var mustache__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! mustache */ "./node_modules/mustache/mustache.mjs");
/* harmony import */ var papaparse__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! papaparse */ "./node_modules/papaparse/papaparse.min.js");
/* harmony import */ var papaparse__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(papaparse__WEBPACK_IMPORTED_MODULE_2__);



class MetricCommon {
    constructor(chrome) {
        this.cloudScrapeUrl = `https://us-central1-promptplusai.cloudfunctions.net/lobbyApi/session/external/scrapeurl`;
        this.activeTabsBeingScraped = [];
        this.metricTypes = ["score 0-10", "text", "json"];
        this.generatePromptTemplate = `Edit the prompt example template based on the following description. Only return the new prompt template. Do not include the description or example template in the response.
Description for new prompt template: 
{{description}}
    
Example prompt template:
{{exampleTemplate}}`;
        this.chrome = chrome;
        this.extCommon = new _extensioncommon__WEBPACK_IMPORTED_MODULE_0__.AnalyzerExtensionCommon(chrome);
        // for detecting in browser scraping completion
        chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
            if (this.activeTabsBeingScraped[tabId] && changeInfo.status === "complete") {
                this.activeTabsBeingScraped[tabId]();
            }
        });
    }
    async getURLContentSource() {
        let value = await this.chrome.storage.local.get("sidePanelUrlSource");
        value = value["sidePanelUrlSource"] || '';
        return value;
    }
    async getSourceType() {
        let value = await this.chrome.storage.local.get("sidePanelSource");
        value = value["sidePanelSource"] || '';
        if (value === 'scrape') {
            return 'scrape';
        }
        else {
            return 'text';
        }
    }
    async sidePanelScrapeUrl() {
        const url = await this.getURLContentSource();
        let sidePanelScrapeType = await this.extCommon.getStorageField("sidePanelScrapeType");
        const options = await this.extCommon.getStorageField("sidePanelUrlSourceOptions");
        let bulkUrl = {
            url,
            scrape: sidePanelScrapeType,
            options,
        };
        if (sidePanelScrapeType === "browser scrape") {
            this.extCommon.enabledBrowserScrapePermissions();
        }
        const activeTab = await this.chrome.tabs.getCurrent();
        const result = await this.scrapeBulkUrl(bulkUrl, activeTab?.id);
        let text = "";
        if (result && result.text)
            text = result.text;
        if (result && result.length > 0 && result[0].result)
            text = result[0].result;
        if (!text)
            text = result.result.text || "";
        text = text.slice(0, await this.extCommon.getEmbeddingCharacterLimit());
        await this.chrome.storage.local.set({ sidePanelScrapeContent: text });
    }
    async detectTabLoaded(tabId) {
        return new Promise((resolve, reject) => {
            this.activeTabsBeingScraped[tabId] = resolve;
        });
    }
    async scrapeTabPage(url, tabId) {
        return new Promise(async (resolve, reject) => {
            let tab = await this.chrome.tabs.create({
                url
            });
            if (tabId) {
                this.chrome.tabs.update(tabId, { active: true });
            }
            await this.detectTabLoaded(tab.id);
            setTimeout(async () => {
                try {
                    let scrapes = await this.chrome.scripting.executeScript({
                        target: { tabId: tab.id },
                        func: () => {
                            return document.body.innerText;
                        },
                    });
                    const updatedTab = await this.chrome.tabs.get(tab.id);
                    scrapes.title = updatedTab.title;
                    await this.chrome.tabs.remove(tab.id);
                    resolve(scrapes);
                }
                catch (e) {
                    console.log("tab scrape error", e);
                    resolve("");
                }
            }, 3000);
        });
    }
    async scrapeBulkUrl(bulkUrl, defaultTabId) {
        let scrape = bulkUrl.scrape;
        let url = bulkUrl.url || "";
        let options = bulkUrl.options || "";
        if (scrape === "server scrape") {
            const result = await this.scrapeUrlServerSide(url, options);
            if (result.success) {
                return {
                    text: result.result.text,
                    title: result.result.title,
                };
            }
            return {
                text: "No text found in page",
                title: "",
            };
        }
        else if (scrape === "browser scrape") {
            let results = await this.scrapeTabPage(url, defaultTabId);
            console.log("active scrape results", results);
            return results;
        }
        else if (scrape === "override content") {
            return {
                text: bulkUrl.content,
                url,
                title: "",
            };
        }
        else {
            return {
                text: "No text found in page",
                title: "",
                url
            };
        }
    }
    async scrapeUrlServerSide(url, options) {
        const result = await this.scrapeURLUsingAPI(url, options);
        result.url = url;
        return result;
    }
    async serverScrapeUrl(url, htmlElementsSelector) {
        let options = `urlScrape=true`;
        if (htmlElementsSelector) {
            options += `||htmlElementsSelector=${htmlElementsSelector}`;
        }
        let result = await this.scrapeUrlServerSide(url, options);
        if (result.success) {
            return {
                text: result.result.text,
                title: result.result.title,
            };
        }
        return {
            text: "No text found in page",
            title: "",
        };
    }
    async scrapeURLUsingAPI(url, options) {
        let apiToken = await this.chrome.storage.local.get('apiToken');
        apiToken = apiToken.apiToken || '';
        let sessionId = await this.chrome.storage.local.get('sessionId');
        sessionId = sessionId.sessionId || '';
        const body = {
            apiToken,
            sessionId,
            url,
            options,
        };
        try {
            const fetchResults = await fetch(this.cloudScrapeUrl, {
                method: "POST",
                mode: "cors",
                cache: "no-cache",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(body),
            });
            return await fetchResults.json();
        }
        catch (err) {
            return {
                success: false,
                error: err,
            };
        }
    }
    async runBulkAnalysis(rows) {
        const isAlreadyRunning = await this.extCommon.setBulkRunning();
        if (isAlreadyRunning) {
            if (confirm("Bulk analysis is already running. Do you want to continue?") === false) {
                return;
            }
        }
        let browserScrape = false;
        rows.forEach((row) => {
            if (row.scrape === "browser scrape") {
                browserScrape = true;
            }
        });
        if (browserScrape) {
            if (confirm("Browser scraping is enabled. This will open tabs in your browser to scrape the pages. Do you want to continue?") === false) {
                return;
            }
            await this.extCommon.enabledBrowserScrapePermissions();
        }
        const runId = new Date().toISOString();
        let urls = [];
        let promises = [];
        const activeTab = await this.chrome.tabs.getCurrent();
        rows.forEach((row) => {
            urls.push(row.url);
            promises.push(this.scrapeBulkUrl(row, activeTab.id));
        });
        let results = await Promise.all(promises);
        let analysisPromises = [];
        results.forEach((result, index) => {
            let text = "";
            if (result && result.text)
                text = result.text;
            if (result && result.length > 0 && result[0].result)
                text = result[0].result;
            if (!text) {
                analysisPromises.push((async () => {
                    return {
                        text: "No text found in page",
                        url: urls[index],
                        results: [],
                        runDate: new Date().toISOString(),
                        title: "",
                    };
                })());
            }
            else {
                analysisPromises.push((async () => {
                    text = text.slice(0, await this.extCommon.getEmbeddingCharacterLimit());
                    return this.runAnalysisPrompts(text, urls[index], null, "selectedBulkAnalysisSets", false, result.title);
                })());
            }
        });
        let analysisResults = await Promise.all(analysisPromises);
        const fullCloudUploadResult = await this.extCommon.writeCloudDataUsingUnacogAPI(runId + ".json", analysisResults);
        const compactData = this.extCommon.processRawResultstoCompact(analysisResults);
        const csv = papaparse__WEBPACK_IMPORTED_MODULE_2___default().unparse(compactData);
        const compactResult = await this.extCommon.writeCloudDataUsingUnacogAPI(runId, csv, "text/csv", "csv");
        let bulkHistory = await this.chrome.storage.local.get('bulkHistory');
        let bulkHistoryRangeLimit = await this.chrome.storage.local.get('bulkHistoryRangeLimit');
        bulkHistoryRangeLimit = Number(bulkHistoryRangeLimit.bulkHistoryRangeLimit) || 100;
        bulkHistory = bulkHistory.bulkHistory || [];
        bulkHistory.unshift({
            runId,
            urls,
            compactResultPath: compactResult.publicStorageUrlPath,
            analysisResultPath: fullCloudUploadResult.publicStorageUrlPath,
        });
        bulkHistory = bulkHistory.slice(0, bulkHistoryRangeLimit);
        await this.chrome.storage.local.set({
            bulkHistory,
            bulk_running: false,
        });
    }
    async runAnalysisPrompts(text, url = "", promptToUse = null, selectedSetName = "selectedAnalysisSets", addToHistory = true, title = "") {
        if (text.length > 30000)
            text = text.slice(0, await this.extCommon.getEmbeddingCharacterLimit());
        const runDate = new Date().toISOString();
        let prompts = [];
        let analysisPrompts = await this.getAnalysisPrompts();
        let selectedAnalysisSets = await this.chrome.storage.local.get(selectedSetName);
        if (promptToUse) {
            prompts = [promptToUse];
        }
        else if (selectedAnalysisSets && selectedAnalysisSets[selectedSetName]) {
            selectedAnalysisSets = selectedAnalysisSets[selectedSetName];
            for (let set of selectedAnalysisSets) {
                let localPrompts = analysisPrompts.filter((prompt) => prompt.setName === set);
                localPrompts.forEach((prompt) => {
                    prompts.push(prompt);
                });
            }
        }
        const runPrompt = async (prompt, text) => {
            let fullPrompt = await this.sendPromptForMetric(prompt.template, text);
            let result = await this.extCommon.processPromptUsingUnacogAPI(fullPrompt);
            return {
                prompt,
                result,
            };
        };
        let promises = [];
        for (let prompt of prompts) {
            promises.push(runPrompt(prompt, text));
        }
        let results = await Promise.all(promises);
        let historyEntry = {
            text,
            results,
            runDate,
            url,
            title,
        };
        if (addToHistory) {
            let history = await this.chrome.storage.local.get('history');
            let historyRangeLimit = await this.chrome.storage.local.get('historyRangeLimit');
            historyRangeLimit = Number(historyRangeLimit.historyRangeLimit) || 10;
            history = history.history || [];
            history.unshift(historyEntry);
            history = history.slice(0, historyRangeLimit);
            await this.chrome.storage.local.set({
                history,
                metrics_running: false,
            });
        }
        return historyEntry;
    }
    async sendPromptForMetric(promptTemplate, query) {
        try {
            const charLimit = await this.extCommon.getEmbeddingCharacterLimit();
            const q = query.slice(0, charLimit);
            let result = mustache__WEBPACK_IMPORTED_MODULE_1__["default"].render(promptTemplate, { query: q });
            return result;
        }
        catch (error) {
            console.log(promptTemplate, query, error);
            return `{
            "contentRating": -1
          }`;
        }
    }
    async setMetricsRunning(prompt = false) {
        let running = await this.chrome.storage.local.get('metrics_running');
        if (running && running.running) {
            return true;
        }
        await this.chrome.storage.local.set({
            metrics_running: true,
        });
        return false;
    }
    async getDefaultAnalysisPrompts() {
        const promptListFile = await fetch("/defaults/promptDefaultsList.json");
        const defaultPromptList = await promptListFile.json();
        const promises = [];
        defaultPromptList.forEach((url) => {
            promises.push((async (url) => {
                let promptQuery = await fetch("/defaults/" + url + ".json");
                let defaultPrompts = await promptQuery.json();
                const allPrompts = [];
                defaultPrompts.forEach((prompt) => {
                    prompt.setName = url;
                    allPrompts.push(prompt);
                });
                return allPrompts;
            })(url));
        });
        const defaultPrompts = await Promise.all(promises);
        const resultPrompts = [];
        defaultPrompts.forEach((promptList, index) => {
            promptList.forEach((prompt) => {
                resultPrompts.push(prompt);
            });
        });
        return resultPrompts;
    }
    async getAnalysisPrompts() {
        let metrics = await this.getDefaultAnalysisPrompts();
        const masterAnalysisList = await this.extCommon.getStorageField('masterAnalysisList') || [];
        if (masterAnalysisList.length > 0) {
            metrics = masterAnalysisList;
        }
        return metrics;
    }
    async getAnalysisSetNames() {
        let allPrompts = await this.getAnalysisPrompts();
        let analysisSets = {};
        allPrompts.forEach((prompt) => {
            if (!analysisSets[prompt.setName]) {
                analysisSets[prompt.setName] = [];
            }
            analysisSets[prompt.setName].push(prompt);
        });
        return Object.keys(analysisSets);
    }
    async generateMetricTemplate(exampleTemplate, description) {
        const result = mustache__WEBPACK_IMPORTED_MODULE_1__["default"].render(this.generatePromptTemplate, { exampleTemplate, description });
        let newPromptContent = (await this.extCommon.processPromptUsingUnacogAPI(result)).resultMessage;
        return newPromptContent;
    }
}


/***/ }),

/***/ "./src/semanticcommon.ts":
/*!*******************************!*\
  !*** ./src/semanticcommon.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SemanticCommon: () => (/* binding */ SemanticCommon)
/* harmony export */ });
/* harmony import */ var _dmdefaultindexes_json__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dmdefaultindexes.json */ "./src/dmdefaultindexes.json");
/* harmony import */ var _defaults_semanticPromptTemplates_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../defaults/semanticPromptTemplates.json */ "./defaults/semanticPromptTemplates.json");
/* harmony import */ var _extensioncommon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./extensioncommon */ "./src/extensioncommon.ts");
/* harmony import */ var mustache__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! mustache */ "./node_modules/mustache/mustache.mjs");




class SemanticCommon {
    constructor(chrome) {
        this.queryUrl = `https://us-central1-promptplusai.cloudfunctions.net/lobbyApi/session/external/vectorquery`;
        this.lookUpKeys = [];
        this.lookedUpIds = {};
        this.lookupData = {};
        this.chunkSizeMeta = {
            apiToken: "",
            sessionId: "",
            lookupPath: "",
            numberOfParts: 0,
            useDefaultSession: false,
        };
        this.chunkSizeMetaDataMap = {};
        this.semanticPromptTemplatesMap = {};
        this.chrome = chrome;
        this.extCommon = new _extensioncommon__WEBPACK_IMPORTED_MODULE_2__.AnalyzerExtensionCommon(chrome);
        _dmdefaultindexes_json__WEBPACK_IMPORTED_MODULE_0__.forEach((defaultData) => {
            let key = defaultData.title;
            if (!key)
                console.log("chunkSizeMetaData missing title", defaultData);
            this.chunkSizeMetaDataMap[key] = defaultData;
        });
        _defaults_semanticPromptTemplates_json__WEBPACK_IMPORTED_MODULE_1__.forEach((defaultData) => {
            let key = defaultData.title;
            if (!key)
                console.log("semanticPromptTemplates missing title", defaultData);
            this.semanticPromptTemplatesMap[key] = defaultData;
        });
    }
    async getSemanticFilters() {
        return (await this.extCommon.getStorageField("selectedSemanticFilters")) || [];
    }
    async fetchDocumentsLookup(idList) {
        const promises = [];
        const docIdMap = {};
        idList.forEach((chunkId) => {
            const parts = chunkId.split("_");
            let docId = parts[0];
            if (this.chunkSizeMeta.numberOfParts === 2) {
                docId = parts[0] + "_" + parts[1];
            }
            else if (this.chunkSizeMeta.numberOfParts === 3) {
                docId = parts[0] + "_" + parts[1] + "_" + parts[2];
            }
            if (this.lookedUpIds[docId] !== true)
                docIdMap[docId] = true;
        });
        Object.keys(docIdMap).forEach((id) => promises.push(this.loadDocumentLookup(id)));
        let chunkMaps = await Promise.all(promises);
        chunkMaps.forEach((chunkMap) => {
            Object.keys(chunkMap).forEach((chunkId) => {
                this.lookupData[chunkId] = chunkMap[chunkId];
            });
        });
        Object.assign(this.lookedUpIds, docIdMap);
        this.lookUpKeys = Object.keys(this.lookupData).sort();
    }
    async setSemanticRunning(prompt = false) {
        let semantic_running = await this.chrome.storage.local.get('semantic_running');
        if (semantic_running && semantic_running.semantic_running) {
            return true;
        }
        await this.chrome.storage.local.set({
            semantic_running: true,
        });
        return false;
    }
    async loadDocumentLookup(docId) {
        try {
            let lookupPath = this.chunkSizeMeta.lookupPath;
            lookupPath = lookupPath.replace("DOC_ID_URIENCODED", docId);
            const r = await fetch(lookupPath);
            const result = await r.json();
            return result;
        }
        catch (error) {
            console.log("FAILED TO FETCH CHUNK MAP", docId, error);
            return {};
        }
    }
    async semanticLoad() {
        this.lookupData = {};
        this.lookedUpIds = {};
    }
    async selectSemanticSource(selectedSemanticSource, clearStorage = false) {
        this.chunkSizeMeta = this.chunkSizeMetaDataMap[selectedSemanticSource];
        await this.chrome.storage.local.set({ selectedSemanticSource });
        if (clearStorage) {
            await this.chrome.storage.local.set({
                semanticResults: {
                    success: true,
                    matches: []
                },
            });
        }
        await this.semanticLoad();
    }
    async querySemanticChunks(message) {
        let selectedSemanticSource = await this.getSelectedSemanticSource();
        const chunkSizeMeta = this.chunkSizeMetaDataMap[selectedSemanticSource];
        this.chunkSizeMeta = chunkSizeMeta;
        let topK = await this.extCommon.getStorageField("topK");
        if (!topK || topK < 1)
            topK = 15;
        let apiToken = chunkSizeMeta.apiToken;
        let sessionId = chunkSizeMeta.sessionId;
        if (chunkSizeMeta.useDefaultSession) {
            topK = 15;
            sessionId = await this.chrome.storage.local.get('sessionId');
            sessionId = sessionId?.sessionId || "";
            apiToken = await this.chrome.storage.local.get('apiToken');
            apiToken = apiToken?.apiToken || "";
        }
        const filter = {};
        const selectedSemanticMetaFilters = await this.getSemanticFilters();
        selectedSemanticMetaFilters.forEach((selectedFilter) => {
            if (selectedFilter.operator === "$se") {
                filter[selectedFilter.metaField] = { ["$eq"]: selectedFilter.value };
            }
            else if (selectedFilter.operator === "$e") {
                const value = Number(selectedFilter.value) || 0;
                filter[selectedFilter.metaField] = { ["$eq"]: value };
            }
            else {
                filter[selectedFilter.metaField] = { [selectedFilter.operator]: Number(selectedFilter.value) };
            }
        });
        const body = {
            message,
            apiToken,
            sessionId,
            topK,
            filter,
        };
        const fetchResults = await fetch(this.queryUrl, {
            method: "POST",
            mode: "cors",
            cache: "no-cache",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(body),
        });
        return await fetchResults.json();
    }
    async getSelectedSemanticSource() {
        return (await this.extCommon.getStorageField("selectedSemanticSource")) || "song full lyrics chunk";
    }
    async getPromptTemplates() {
        const defaultPromptsNames = Object.keys(this.semanticPromptTemplatesMap);
        const defaultPrompts = this.semanticPromptTemplatesMap[defaultPromptsNames[0]];
        let promptTemplate = await this.extCommon.getStorageField("semanticQueryMainPromptTemplate");
        let documentTemplate = await this.extCommon.getStorageField("semanticQueryDocumentPromptTemplate");
        if (!promptTemplate) {
            promptTemplate = defaultPrompts.mainPrompt;
            await this.chrome.storage.local.set({ semanticQueryMainPromptTemplate: promptTemplate });
        }
        if (!documentTemplate) {
            documentTemplate = defaultPrompts.documentPrompt;
            await this.chrome.storage.local.set({ semanticQueryDocumentPromptTemplate: documentTemplate });
        }
        return {
            promptTemplate,
            documentTemplate,
        };
    }
    async semanticQuery() {
        const message = await this.extCommon.getStorageField("semanticQueryText");
        await this.chrome.storage.local.set({
            semanticResults: {
                success: true,
                matches: []
            },
            semantic_running: true,
        });
        if (!message)
            return;
        const semanticResults = await this.querySemanticChunks(message);
        if (semanticResults.success === false || !semanticResults.matches
            || semanticResults.matches.length === 0) {
            await this.chrome.storage.local.set({
                semanticResults,
                semanticChunkRows: [],
                semantic_running: false,
            });
            return;
        }
        await this.fetchDocumentsLookup(semanticResults.matches.map((match) => match.id));
        const chunkIncludedMap = {};
        let includeK = Number(await this.extCommon.getStorageField("semanticIncludeK"));
        if (!includeK || includeK < 1)
            includeK = 5;
        const columnMap = {};
        const usedDocuments = {};
        const uniqueDocsChecked = (await this.extCommon.getStorageField("uniqueSemanticDocs")) === true;
        const eligibleDocs = [];
        semanticResults.matches.forEach((match) => {
            const parts = match.id.split("_");
            const docID = parts[0];
            if (!usedDocuments[docID] || !uniqueDocsChecked) {
                usedDocuments[docID] = true;
                eligibleDocs.push(match);
            }
        });
        eligibleDocs.slice(0, includeK).forEach((match) => {
            chunkIncludedMap[match.id] = true;
            Object.keys(match.metadata).forEach((key) => {
                columnMap[key] = true;
            });
        });
        const columnMapKeys = Object.keys(columnMap);
        const columnsUsed = {};
        const semanticChunkColumns = [{
                formatter: "rowSelection",
                titleFormatter: "rowSelection",
                headerSort: false,
                resizable: false,
                headerHozAlign: "center",
                hozAlign: "center",
                title: "",
            }, {
                title: "Id",
                field: "id",
                width: 100,
                headerSort: false,
            }, {
                title: "Text",
                field: "text",
                width: 300,
                headerSort: false,
            }];
        columnsUsed["include"] = true;
        columnsUsed["id"] = true;
        columnsUsed["text"] = true;
        columnMapKeys.forEach((key) => {
            if (!columnsUsed[key]) {
                semanticChunkColumns.push({
                    title: key,
                    field: key,
                    width: 100,
                    headerSort: false,
                });
                columnsUsed[key] = true;
            }
        });
        const semanticChunkRows = [];
        semanticResults.matches.forEach((match) => {
            match.fullText = this.lookupData[match.id];
            if (!match.fullText) {
                console.log(match.id, this.lookupData);
            }
            const chunkDetails = {};
            Object.assign(chunkDetails, match.metadata);
            chunkDetails.id = match.id;
            chunkDetails.text = match.fullText;
            chunkDetails.include = chunkIncludedMap[match.id] ? true : false;
            const keys = Object.keys(chunkDetails);
            keys.forEach((key) => {
                if (!columnMap[key]) {
                    columnMap[key] = true;
                }
            });
            semanticChunkRows.push(chunkDetails);
        });
        await this.chrome.storage.local.set({
            semanticResults,
            semanticChunkRows,
            semanticChunkColumns,
            semantic_running: false,
        });
    }
    async buildChunkEmbedText(message, semanticChunkRows, includeSpanTags = false) {
        let documentsEmbedText = "";
        const contextK = Number(await this.extCommon.getStorageField("semanticContextK")) || 1;
        const includedRows = semanticChunkRows.filter((row) => row.include);
        const promptTemplates = await this.getPromptTemplates();
        await this.fetchDocumentsLookup(includedRows.map((row) => row.id));
        let documentTemplate = promptTemplates.documentTemplate;
        if (includeSpanTags) {
            documentTemplate = `<span class="document_embedded_chunk">${documentTemplate}</span>`;
        }
        includedRows.forEach((row, index) => {
            const merge = Object.assign({}, row);
            merge.text = this.getSmallToBig(row.id, contextK);
            merge.prompt = message;
            if (!merge.text) {
                console.log("missing merge", row.id, this.lookupData);
                merge.text = "";
            }
            merge.text = merge.text.replaceAll("\n", " ");
            documentsEmbedText += mustache__WEBPACK_IMPORTED_MODULE_3__["default"].render(documentTemplate, merge);
        });
        await this.chrome.storage.local.set({
            documentsEmbedText,
        });
        return documentsEmbedText;
    }
    async getEmbeddedPromptText(includeSpanTags = false) {
        const message = await this.extCommon.getStorageField("semanticQueryText") || "";
        if (!message) {
            console.log("getEmbeddedPromptText: no message found in storage");
        }
        const semanticChunkRows = await this.extCommon.getStorageField("semanticChunkRows") || [];
        let documentsEmbedText = await this.buildChunkEmbedText(message, semanticChunkRows, includeSpanTags);
        const promptTemplates = await this.getPromptTemplates();
        let promptT = promptTemplates.promptTemplate;
        if (includeSpanTags) {
            documentsEmbedText = `<span class="documents_embed_section">${documentsEmbedText}</span>`;
        }
        const mainMerge = {
            documents: documentsEmbedText,
            prompt: message,
        };
        const mainPrompt = mustache__WEBPACK_IMPORTED_MODULE_3__["default"].render(promptT, mainMerge);
        return mainPrompt;
    }
    getSmallToBig(matchId, contextK) {
        const lookUpIndex = this.lookUpKeys.indexOf(matchId);
        let firstIndex = lookUpIndex - Math.floor(contextK / 2);
        let lastIndex = lookUpIndex + Math.ceil(contextK / 2);
        if (firstIndex < 0)
            firstIndex = 0;
        if (lastIndex > this.lookUpKeys.length - 1)
            lastIndex = this.lookUpKeys.length - 1;
        const parts = matchId.split("_");
        const docID = parts[0];
        let text = "";
        for (let i = firstIndex; i <= lastIndex; i++) {
            const chunkKey = this.lookUpKeys[i];
            if (!chunkKey)
                continue;
            if (chunkKey.indexOf(docID) === 0) {
                if (this.lookupData[chunkKey]) {
                    text = this.annexChunkWithoutOverlap(text, this.lookupData[chunkKey]);
                }
            }
        }
        return text;
    }
    annexChunkWithoutOverlap(text, chunkText, searchDepth = 500) {
        let startPos = -1;
        const l = Math.min(chunkText.length - 1, searchDepth);
        for (let nextPos = 1; nextPos < l; nextPos++) {
            const existingOverlap = text.slice(-1 * nextPos);
            const nextOverlap = chunkText.slice(0, nextPos);
            if (existingOverlap === nextOverlap) {
                startPos = nextPos;
                // break;
            }
        }
        if (startPos > 0) {
            return text + chunkText.slice(startPos) + " ";
        }
        return text + chunkText + " ";
    }
}


/***/ }),

/***/ "./node_modules/mustache/mustache.mjs":
/*!********************************************!*\
  !*** ./node_modules/mustache/mustache.mjs ***!
  \********************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/*!
 * mustache.js - Logic-less {{mustache}} templates with JavaScript
 * http://github.com/janl/mustache.js
 */

var objectToString = Object.prototype.toString;
var isArray = Array.isArray || function isArrayPolyfill (object) {
  return objectToString.call(object) === '[object Array]';
};

function isFunction (object) {
  return typeof object === 'function';
}

/**
 * More correct typeof string handling array
 * which normally returns typeof 'object'
 */
function typeStr (obj) {
  return isArray(obj) ? 'array' : typeof obj;
}

function escapeRegExp (string) {
  return string.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, '\\$&');
}

/**
 * Null safe way of checking whether or not an object,
 * including its prototype, has a given property
 */
function hasProperty (obj, propName) {
  return obj != null && typeof obj === 'object' && (propName in obj);
}

/**
 * Safe way of detecting whether or not the given thing is a primitive and
 * whether it has the given property
 */
function primitiveHasOwnProperty (primitive, propName) {
  return (
    primitive != null
    && typeof primitive !== 'object'
    && primitive.hasOwnProperty
    && primitive.hasOwnProperty(propName)
  );
}

// Workaround for https://issues.apache.org/jira/browse/COUCHDB-577
// See https://github.com/janl/mustache.js/issues/189
var regExpTest = RegExp.prototype.test;
function testRegExp (re, string) {
  return regExpTest.call(re, string);
}

var nonSpaceRe = /\S/;
function isWhitespace (string) {
  return !testRegExp(nonSpaceRe, string);
}

var entityMap = {
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;',
  '/': '&#x2F;',
  '`': '&#x60;',
  '=': '&#x3D;'
};

function escapeHtml (string) {
  return String(string).replace(/[&<>"'`=\/]/g, function fromEntityMap (s) {
    return entityMap[s];
  });
}

var whiteRe = /\s*/;
var spaceRe = /\s+/;
var equalsRe = /\s*=/;
var curlyRe = /\s*\}/;
var tagRe = /#|\^|\/|>|\{|&|=|!/;

/**
 * Breaks up the given `template` string into a tree of tokens. If the `tags`
 * argument is given here it must be an array with two string values: the
 * opening and closing tags used in the template (e.g. [ "<%", "%>" ]). Of
 * course, the default is to use mustaches (i.e. mustache.tags).
 *
 * A token is an array with at least 4 elements. The first element is the
 * mustache symbol that was used inside the tag, e.g. "#" or "&". If the tag
 * did not contain a symbol (i.e. {{myValue}}) this element is "name". For
 * all text that appears outside a symbol this element is "text".
 *
 * The second element of a token is its "value". For mustache tags this is
 * whatever else was inside the tag besides the opening symbol. For text tokens
 * this is the text itself.
 *
 * The third and fourth elements of the token are the start and end indices,
 * respectively, of the token in the original template.
 *
 * Tokens that are the root node of a subtree contain two more elements: 1) an
 * array of tokens in the subtree and 2) the index in the original template at
 * which the closing tag for that section begins.
 *
 * Tokens for partials also contain two more elements: 1) a string value of
 * indendation prior to that tag and 2) the index of that tag on that line -
 * eg a value of 2 indicates the partial is the third tag on this line.
 */
function parseTemplate (template, tags) {
  if (!template)
    return [];
  var lineHasNonSpace = false;
  var sections = [];     // Stack to hold section tokens
  var tokens = [];       // Buffer to hold the tokens
  var spaces = [];       // Indices of whitespace tokens on the current line
  var hasTag = false;    // Is there a {{tag}} on the current line?
  var nonSpace = false;  // Is there a non-space char on the current line?
  var indentation = '';  // Tracks indentation for tags that use it
  var tagIndex = 0;      // Stores a count of number of tags encountered on a line

  // Strips all whitespace tokens array for the current line
  // if there was a {{#tag}} on it and otherwise only space.
  function stripSpace () {
    if (hasTag && !nonSpace) {
      while (spaces.length)
        delete tokens[spaces.pop()];
    } else {
      spaces = [];
    }

    hasTag = false;
    nonSpace = false;
  }

  var openingTagRe, closingTagRe, closingCurlyRe;
  function compileTags (tagsToCompile) {
    if (typeof tagsToCompile === 'string')
      tagsToCompile = tagsToCompile.split(spaceRe, 2);

    if (!isArray(tagsToCompile) || tagsToCompile.length !== 2)
      throw new Error('Invalid tags: ' + tagsToCompile);

    openingTagRe = new RegExp(escapeRegExp(tagsToCompile[0]) + '\\s*');
    closingTagRe = new RegExp('\\s*' + escapeRegExp(tagsToCompile[1]));
    closingCurlyRe = new RegExp('\\s*' + escapeRegExp('}' + tagsToCompile[1]));
  }

  compileTags(tags || mustache.tags);

  var scanner = new Scanner(template);

  var start, type, value, chr, token, openSection;
  while (!scanner.eos()) {
    start = scanner.pos;

    // Match any text between tags.
    value = scanner.scanUntil(openingTagRe);

    if (value) {
      for (var i = 0, valueLength = value.length; i < valueLength; ++i) {
        chr = value.charAt(i);

        if (isWhitespace(chr)) {
          spaces.push(tokens.length);
          indentation += chr;
        } else {
          nonSpace = true;
          lineHasNonSpace = true;
          indentation += ' ';
        }

        tokens.push([ 'text', chr, start, start + 1 ]);
        start += 1;

        // Check for whitespace on the current line.
        if (chr === '\n') {
          stripSpace();
          indentation = '';
          tagIndex = 0;
          lineHasNonSpace = false;
        }
      }
    }

    // Match the opening tag.
    if (!scanner.scan(openingTagRe))
      break;

    hasTag = true;

    // Get the tag type.
    type = scanner.scan(tagRe) || 'name';
    scanner.scan(whiteRe);

    // Get the tag value.
    if (type === '=') {
      value = scanner.scanUntil(equalsRe);
      scanner.scan(equalsRe);
      scanner.scanUntil(closingTagRe);
    } else if (type === '{') {
      value = scanner.scanUntil(closingCurlyRe);
      scanner.scan(curlyRe);
      scanner.scanUntil(closingTagRe);
      type = '&';
    } else {
      value = scanner.scanUntil(closingTagRe);
    }

    // Match the closing tag.
    if (!scanner.scan(closingTagRe))
      throw new Error('Unclosed tag at ' + scanner.pos);

    if (type == '>') {
      token = [ type, value, start, scanner.pos, indentation, tagIndex, lineHasNonSpace ];
    } else {
      token = [ type, value, start, scanner.pos ];
    }
    tagIndex++;
    tokens.push(token);

    if (type === '#' || type === '^') {
      sections.push(token);
    } else if (type === '/') {
      // Check section nesting.
      openSection = sections.pop();

      if (!openSection)
        throw new Error('Unopened section "' + value + '" at ' + start);

      if (openSection[1] !== value)
        throw new Error('Unclosed section "' + openSection[1] + '" at ' + start);
    } else if (type === 'name' || type === '{' || type === '&') {
      nonSpace = true;
    } else if (type === '=') {
      // Set the tags for the next time around.
      compileTags(value);
    }
  }

  stripSpace();

  // Make sure there are no open sections when we're done.
  openSection = sections.pop();

  if (openSection)
    throw new Error('Unclosed section "' + openSection[1] + '" at ' + scanner.pos);

  return nestTokens(squashTokens(tokens));
}

/**
 * Combines the values of consecutive text tokens in the given `tokens` array
 * to a single token.
 */
function squashTokens (tokens) {
  var squashedTokens = [];

  var token, lastToken;
  for (var i = 0, numTokens = tokens.length; i < numTokens; ++i) {
    token = tokens[i];

    if (token) {
      if (token[0] === 'text' && lastToken && lastToken[0] === 'text') {
        lastToken[1] += token[1];
        lastToken[3] = token[3];
      } else {
        squashedTokens.push(token);
        lastToken = token;
      }
    }
  }

  return squashedTokens;
}

/**
 * Forms the given array of `tokens` into a nested tree structure where
 * tokens that represent a section have two additional items: 1) an array of
 * all tokens that appear in that section and 2) the index in the original
 * template that represents the end of that section.
 */
function nestTokens (tokens) {
  var nestedTokens = [];
  var collector = nestedTokens;
  var sections = [];

  var token, section;
  for (var i = 0, numTokens = tokens.length; i < numTokens; ++i) {
    token = tokens[i];

    switch (token[0]) {
      case '#':
      case '^':
        collector.push(token);
        sections.push(token);
        collector = token[4] = [];
        break;
      case '/':
        section = sections.pop();
        section[5] = token[2];
        collector = sections.length > 0 ? sections[sections.length - 1][4] : nestedTokens;
        break;
      default:
        collector.push(token);
    }
  }

  return nestedTokens;
}

/**
 * A simple string scanner that is used by the template parser to find
 * tokens in template strings.
 */
function Scanner (string) {
  this.string = string;
  this.tail = string;
  this.pos = 0;
}

/**
 * Returns `true` if the tail is empty (end of string).
 */
Scanner.prototype.eos = function eos () {
  return this.tail === '';
};

/**
 * Tries to match the given regular expression at the current position.
 * Returns the matched text if it can match, the empty string otherwise.
 */
Scanner.prototype.scan = function scan (re) {
  var match = this.tail.match(re);

  if (!match || match.index !== 0)
    return '';

  var string = match[0];

  this.tail = this.tail.substring(string.length);
  this.pos += string.length;

  return string;
};

/**
 * Skips all text until the given regular expression can be matched. Returns
 * the skipped string, which is the entire tail if no match can be made.
 */
Scanner.prototype.scanUntil = function scanUntil (re) {
  var index = this.tail.search(re), match;

  switch (index) {
    case -1:
      match = this.tail;
      this.tail = '';
      break;
    case 0:
      match = '';
      break;
    default:
      match = this.tail.substring(0, index);
      this.tail = this.tail.substring(index);
  }

  this.pos += match.length;

  return match;
};

/**
 * Represents a rendering context by wrapping a view object and
 * maintaining a reference to the parent context.
 */
function Context (view, parentContext) {
  this.view = view;
  this.cache = { '.': this.view };
  this.parent = parentContext;
}

/**
 * Creates a new context using the given view with this context
 * as the parent.
 */
Context.prototype.push = function push (view) {
  return new Context(view, this);
};

/**
 * Returns the value of the given name in this context, traversing
 * up the context hierarchy if the value is absent in this context's view.
 */
Context.prototype.lookup = function lookup (name) {
  var cache = this.cache;

  var value;
  if (cache.hasOwnProperty(name)) {
    value = cache[name];
  } else {
    var context = this, intermediateValue, names, index, lookupHit = false;

    while (context) {
      if (name.indexOf('.') > 0) {
        intermediateValue = context.view;
        names = name.split('.');
        index = 0;

        /**
         * Using the dot notion path in `name`, we descend through the
         * nested objects.
         *
         * To be certain that the lookup has been successful, we have to
         * check if the last object in the path actually has the property
         * we are looking for. We store the result in `lookupHit`.
         *
         * This is specially necessary for when the value has been set to
         * `undefined` and we want to avoid looking up parent contexts.
         *
         * In the case where dot notation is used, we consider the lookup
         * to be successful even if the last "object" in the path is
         * not actually an object but a primitive (e.g., a string, or an
         * integer), because it is sometimes useful to access a property
         * of an autoboxed primitive, such as the length of a string.
         **/
        while (intermediateValue != null && index < names.length) {
          if (index === names.length - 1)
            lookupHit = (
              hasProperty(intermediateValue, names[index])
              || primitiveHasOwnProperty(intermediateValue, names[index])
            );

          intermediateValue = intermediateValue[names[index++]];
        }
      } else {
        intermediateValue = context.view[name];

        /**
         * Only checking against `hasProperty`, which always returns `false` if
         * `context.view` is not an object. Deliberately omitting the check
         * against `primitiveHasOwnProperty` if dot notation is not used.
         *
         * Consider this example:
         * ```
         * Mustache.render("The length of a football field is {{#length}}{{length}}{{/length}}.", {length: "100 yards"})
         * ```
         *
         * If we were to check also against `primitiveHasOwnProperty`, as we do
         * in the dot notation case, then render call would return:
         *
         * "The length of a football field is 9."
         *
         * rather than the expected:
         *
         * "The length of a football field is 100 yards."
         **/
        lookupHit = hasProperty(context.view, name);
      }

      if (lookupHit) {
        value = intermediateValue;
        break;
      }

      context = context.parent;
    }

    cache[name] = value;
  }

  if (isFunction(value))
    value = value.call(this.view);

  return value;
};

/**
 * A Writer knows how to take a stream of tokens and render them to a
 * string, given a context. It also maintains a cache of templates to
 * avoid the need to parse the same template twice.
 */
function Writer () {
  this.templateCache = {
    _cache: {},
    set: function set (key, value) {
      this._cache[key] = value;
    },
    get: function get (key) {
      return this._cache[key];
    },
    clear: function clear () {
      this._cache = {};
    }
  };
}

/**
 * Clears all cached templates in this writer.
 */
Writer.prototype.clearCache = function clearCache () {
  if (typeof this.templateCache !== 'undefined') {
    this.templateCache.clear();
  }
};

/**
 * Parses and caches the given `template` according to the given `tags` or
 * `mustache.tags` if `tags` is omitted,  and returns the array of tokens
 * that is generated from the parse.
 */
Writer.prototype.parse = function parse (template, tags) {
  var cache = this.templateCache;
  var cacheKey = template + ':' + (tags || mustache.tags).join(':');
  var isCacheEnabled = typeof cache !== 'undefined';
  var tokens = isCacheEnabled ? cache.get(cacheKey) : undefined;

  if (tokens == undefined) {
    tokens = parseTemplate(template, tags);
    isCacheEnabled && cache.set(cacheKey, tokens);
  }
  return tokens;
};

/**
 * High-level method that is used to render the given `template` with
 * the given `view`.
 *
 * The optional `partials` argument may be an object that contains the
 * names and templates of partials that are used in the template. It may
 * also be a function that is used to load partial templates on the fly
 * that takes a single argument: the name of the partial.
 *
 * If the optional `config` argument is given here, then it should be an
 * object with a `tags` attribute or an `escape` attribute or both.
 * If an array is passed, then it will be interpreted the same way as
 * a `tags` attribute on a `config` object.
 *
 * The `tags` attribute of a `config` object must be an array with two
 * string values: the opening and closing tags used in the template (e.g.
 * [ "<%", "%>" ]). The default is to mustache.tags.
 *
 * The `escape` attribute of a `config` object must be a function which
 * accepts a string as input and outputs a safely escaped string.
 * If an `escape` function is not provided, then an HTML-safe string
 * escaping function is used as the default.
 */
Writer.prototype.render = function render (template, view, partials, config) {
  var tags = this.getConfigTags(config);
  var tokens = this.parse(template, tags);
  var context = (view instanceof Context) ? view : new Context(view, undefined);
  return this.renderTokens(tokens, context, partials, template, config);
};

/**
 * Low-level method that renders the given array of `tokens` using
 * the given `context` and `partials`.
 *
 * Note: The `originalTemplate` is only ever used to extract the portion
 * of the original template that was contained in a higher-order section.
 * If the template doesn't use higher-order sections, this argument may
 * be omitted.
 */
Writer.prototype.renderTokens = function renderTokens (tokens, context, partials, originalTemplate, config) {
  var buffer = '';

  var token, symbol, value;
  for (var i = 0, numTokens = tokens.length; i < numTokens; ++i) {
    value = undefined;
    token = tokens[i];
    symbol = token[0];

    if (symbol === '#') value = this.renderSection(token, context, partials, originalTemplate, config);
    else if (symbol === '^') value = this.renderInverted(token, context, partials, originalTemplate, config);
    else if (symbol === '>') value = this.renderPartial(token, context, partials, config);
    else if (symbol === '&') value = this.unescapedValue(token, context);
    else if (symbol === 'name') value = this.escapedValue(token, context, config);
    else if (symbol === 'text') value = this.rawValue(token);

    if (value !== undefined)
      buffer += value;
  }

  return buffer;
};

Writer.prototype.renderSection = function renderSection (token, context, partials, originalTemplate, config) {
  var self = this;
  var buffer = '';
  var value = context.lookup(token[1]);

  // This function is used to render an arbitrary template
  // in the current context by higher-order sections.
  function subRender (template) {
    return self.render(template, context, partials, config);
  }

  if (!value) return;

  if (isArray(value)) {
    for (var j = 0, valueLength = value.length; j < valueLength; ++j) {
      buffer += this.renderTokens(token[4], context.push(value[j]), partials, originalTemplate, config);
    }
  } else if (typeof value === 'object' || typeof value === 'string' || typeof value === 'number') {
    buffer += this.renderTokens(token[4], context.push(value), partials, originalTemplate, config);
  } else if (isFunction(value)) {
    if (typeof originalTemplate !== 'string')
      throw new Error('Cannot use higher-order sections without the original template');

    // Extract the portion of the original template that the section contains.
    value = value.call(context.view, originalTemplate.slice(token[3], token[5]), subRender);

    if (value != null)
      buffer += value;
  } else {
    buffer += this.renderTokens(token[4], context, partials, originalTemplate, config);
  }
  return buffer;
};

Writer.prototype.renderInverted = function renderInverted (token, context, partials, originalTemplate, config) {
  var value = context.lookup(token[1]);

  // Use JavaScript's definition of falsy. Include empty arrays.
  // See https://github.com/janl/mustache.js/issues/186
  if (!value || (isArray(value) && value.length === 0))
    return this.renderTokens(token[4], context, partials, originalTemplate, config);
};

Writer.prototype.indentPartial = function indentPartial (partial, indentation, lineHasNonSpace) {
  var filteredIndentation = indentation.replace(/[^ \t]/g, '');
  var partialByNl = partial.split('\n');
  for (var i = 0; i < partialByNl.length; i++) {
    if (partialByNl[i].length && (i > 0 || !lineHasNonSpace)) {
      partialByNl[i] = filteredIndentation + partialByNl[i];
    }
  }
  return partialByNl.join('\n');
};

Writer.prototype.renderPartial = function renderPartial (token, context, partials, config) {
  if (!partials) return;
  var tags = this.getConfigTags(config);

  var value = isFunction(partials) ? partials(token[1]) : partials[token[1]];
  if (value != null) {
    var lineHasNonSpace = token[6];
    var tagIndex = token[5];
    var indentation = token[4];
    var indentedValue = value;
    if (tagIndex == 0 && indentation) {
      indentedValue = this.indentPartial(value, indentation, lineHasNonSpace);
    }
    var tokens = this.parse(indentedValue, tags);
    return this.renderTokens(tokens, context, partials, indentedValue, config);
  }
};

Writer.prototype.unescapedValue = function unescapedValue (token, context) {
  var value = context.lookup(token[1]);
  if (value != null)
    return value;
};

Writer.prototype.escapedValue = function escapedValue (token, context, config) {
  var escape = this.getConfigEscape(config) || mustache.escape;
  var value = context.lookup(token[1]);
  if (value != null)
    return (typeof value === 'number' && escape === mustache.escape) ? String(value) : escape(value);
};

Writer.prototype.rawValue = function rawValue (token) {
  return token[1];
};

Writer.prototype.getConfigTags = function getConfigTags (config) {
  if (isArray(config)) {
    return config;
  }
  else if (config && typeof config === 'object') {
    return config.tags;
  }
  else {
    return undefined;
  }
};

Writer.prototype.getConfigEscape = function getConfigEscape (config) {
  if (config && typeof config === 'object' && !isArray(config)) {
    return config.escape;
  }
  else {
    return undefined;
  }
};

var mustache = {
  name: 'mustache.js',
  version: '4.2.0',
  tags: [ '{{', '}}' ],
  clearCache: undefined,
  escape: undefined,
  parse: undefined,
  render: undefined,
  Scanner: undefined,
  Context: undefined,
  Writer: undefined,
  /**
   * Allows a user to override the default caching strategy, by providing an
   * object with set, get and clear methods. This can also be used to disable
   * the cache by setting it to the literal `undefined`.
   */
  set templateCache (cache) {
    defaultWriter.templateCache = cache;
  },
  /**
   * Gets the default or overridden caching object from the default writer.
   */
  get templateCache () {
    return defaultWriter.templateCache;
  }
};

// All high-level mustache.* functions use this writer.
var defaultWriter = new Writer();

/**
 * Clears all cached templates in the default writer.
 */
mustache.clearCache = function clearCache () {
  return defaultWriter.clearCache();
};

/**
 * Parses and caches the given template in the default writer and returns the
 * array of tokens it contains. Doing this ahead of time avoids the need to
 * parse templates on the fly as they are rendered.
 */
mustache.parse = function parse (template, tags) {
  return defaultWriter.parse(template, tags);
};

/**
 * Renders the `template` with the given `view`, `partials`, and `config`
 * using the default writer.
 */
mustache.render = function render (template, view, partials, config) {
  if (typeof template !== 'string') {
    throw new TypeError('Invalid template! Template should be a "string" ' +
                        'but "' + typeStr(template) + '" was given as the first ' +
                        'argument for mustache#render(template, view, partials)');
  }

  return defaultWriter.render(template, view, partials, config);
};

// Export the escaping function so that the user may override it.
// See https://github.com/janl/mustache.js/issues/244
mustache.escape = escapeHtml;

// Export these mainly for testing, but also for advanced usage.
mustache.Scanner = Scanner;
mustache.Context = Context;
mustache.Writer = Writer;

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (mustache);


/***/ }),

/***/ "./defaults/semanticPromptTemplates.json":
/*!***********************************************!*\
  !*** ./defaults/semanticPromptTemplates.json ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = /*#__PURE__*/JSON.parse('[{"title":"Answer with Doc Summary","mainPrompt":"Given the context information below and without prior knowledge, please answer the query.\\nContext:{{{documents}}}\\n\\nQuery: {{prompt}}\\n\\nOverall Response to Query based on all documents:\\n\\nIn addition, respond for each document using the following format:\\nTitle:\\nSummary:","documentPrompt":"Title: {{title}}:\\n{{text}}\\n\\n"},{"title":"OpenAI Cookbook Primitive","mainPrompt":"Answer the question based on the context below.\\nContext:\\n{{{documents}}}\\nQuestion: {{prompt}}\\nAnswer:","documentPrompt":"Question: {{prompt}}\\nAnswer: {{text}}\\n"},{"title":"Answer with Doc Keywords","mainPrompt":"Given the context information below and without prior knowledge, please answer the query.\\nContext:{{{documents}}}\\nQuery: {{prompt}}\\n\\nProvide title and a list of keywords for each document:","documentPrompt":"Title: {{title}}:\\n{{text}}\\n"}]');

/***/ }),

/***/ "./src/dmdefaultindexes.json":
/*!***********************************!*\
  !*** ./src/dmdefaultindexes.json ***!
  \***********************************/
/***/ ((module) => {

"use strict";
module.exports = /*#__PURE__*/JSON.parse('[{"title":"bible chunked by chapter","apiToken":"a1316745-313f-4bdf-b073-3705bf11a0e7","numberOfParts":2,"sessionId":"vkuyk8lg74nq","lookupPath":"https://firebasestorage.googleapis.com/v0/b/promptplusai.appspot.com/o/projectLookups%2FHlm0AZ9mUCeWrMF6hI7SueVPbrq1%2Fbiblechapters-gen3%2FbyDocument%2FDOC_ID_URIENCODED.json?alt=media","topK":15},{"title":"bible chunked by verse","apiToken":"9b2b6dcc-900d-4051-9947-a42830853d86","sessionId":"lh3a4fui9n7j","lookupPath":"https://firebasestorage.googleapis.com/v0/b/promptplusai.appspot.com/o/projectLookups%2FHlm0AZ9mUCeWrMF6hI7SueVPbrq1%2Fbibleverses-gen3-v2%2FbyDocument%2FDOC_ID_URIENCODED.json?alt=media","topK":15},{"title":"song full lyrics chunk","apiToken":"cfbde57f-a4e6-4eb9-aea4-36d5fbbdad16","sessionId":"8umxl4rdt32x","lookupPath":"https://firebasestorage.googleapis.com/v0/b/promptplusai.appspot.com/o/projectLookups%2FHlm0AZ9mUCeWrMF6hI7SueVPbrq1%2Fsong-demo-v3%2FbyDocument%2FDOC_ID_URIENCODED.json?alt=media","topK":15},{"title":"song stanza chunk","apiToken":"b0a5f137-b5ff-4b78-8074-79a3f775a212","sessionId":"prg66uadseer","lookupPath":"https://firebasestorage.googleapis.com/v0/b/promptplusai.appspot.com/o/projectLookups%2FHlm0AZ9mUCeWrMF6hI7SueVPbrq1%2Fsong-demo-v6-4-1%2FbyDocument%2FDOC_ID_URIENCODED.json?alt=media","topK":15},{"title":"song verse chunk","apiToken":"6b71e856-1dee-4f9d-bd53-64b6adafc592","sessionId":"bsec9cwrpl72","lookupPath":"https://firebasestorage.googleapis.com/v0/b/promptplusai.appspot.com/o/projectLookups%2FHlm0AZ9mUCeWrMF6hI7SueVPbrq1%2Fsong-demo-v6-verse%2FbyDocument%2FDOC_ID_URIENCODED.json?alt=media","topK":15},{"title":"song double stanza chunk","apiToken":"3b09a640-7f63-4776-becc-7deab9b9507c","sessionId":"ux4odeb8jqu7","lookupPath":"https://firebasestorage.googleapis.com/v0/b/promptplusai.appspot.com/o/projectLookups%2FHlm0AZ9mUCeWrMF6hI7SueVPbrq1%2Fsong-demo-v3-double-stanze%2FbyDocument%2FDOC_ID_URIENCODED.json?alt=media","topK":15},{"title":"AI archive - 100 chunk","apiToken":"8b9e7b73-cad1-44c7-9a3b-07eb6914bc1a","sessionId":"h3gb1s7uxt02","lookupPath":"https://firebasestorage.googleapis.com/v0/b/promptplusai.appspot.com/o/projectLookups%2FHlm0AZ9mUCeWrMF6hI7SueVPbrq1%2Far-arxiv-full-100%2FbyDocument%2FDOC_ID_URIENCODED.json?alt=media","topK":15},{"title":"AI archive - 200 chunk","apiToken":"96b0d708-ec04-4da5-bcf3-783ffc5329eb","sessionId":"x5m51v87x7g8","lookupPath":"https://firebasestorage.googleapis.com/v0/b/promptplusai.appspot.com/o/projectLookups%2FiMY1WwR6NkVnNkLId5bnKT59Np42%2Far-arxiv-full%2FbyDocument%2FDOC_ID_URIENCODED.json?alt=media","topK":10},{"title":"AI archive - 300 chunk","apiToken":"7f585847-9c4b-4da8-99e8-4102408f1564","sessionId":"2pa7jvukf892","lookupPath":"https://firebasestorage.googleapis.com/v0/b/promptplusai.appspot.com/o/projectLookups%2Farxivchunkedv2%2FDOC_ID_URIENCODED.json?alt=media","topK":8},{"title":"AI archive - 400 chunk","apiToken":"8168ca87-2017-49ad-a8f3-bba00683e7de","sessionId":"ppdbgryy52mn","lookupPath":"https://firebasestorage.googleapis.com/v0/b/promptplusai.appspot.com/o/projectLookups%2FHlm0AZ9mUCeWrMF6hI7SueVPbrq1%2Far-arxiv-full-400%2FbyDocument%2FDOC_ID_URIENCODED.json?alt=media","topK":5},{"title":"Covid articles (science.org) - normal","description":"Sentence blocks sized 300 tokens","numberOfParts":2,"apiToken":"338ddcc0-e083-4057-a6bc-6ceecbd98cf6","sessionId":"4fg8acknmo5u","lookupPath":"https://firebasestorage.googleapis.com/v0/b/promptplusai.appspot.com/o/projectLookups%2FHlm0AZ9mUCeWrMF6hI7SueVPbrq1%2Fcovid-sizechunk-v3%2FbyDocument%2FDOC_ID_URIENCODED.json?alt=media","topK":10},{"title":"Covid articles (science.org) - recursive","description":"Max Size: 300 tokens / 20 overlap","numberOfParts":2,"apiToken":"12781bbc-5d71-4359-831b-377e06d4a27b","sessionId":"cyf1pd1l4wpc","lookupPath":"https://firebasestorage.googleapis.com/v0/b/promptplusai.appspot.com/o/projectLookups%2FHlm0AZ9mUCeWrMF6hI7SueVPbrq1%2Fcovid-list-v3%2FbyDocument%2FDOC_ID_URIENCODED.json?alt=media","topK":10},{"title":"Covid articles (science.org) - sentence","description":"15 sentence blocks with 3 overlap","numberOfParts":2,"apiToken":"1d4fffc7-5257-4ccd-bba3-6e96fcfd4722","sessionId":"1gcrc37j1miq","lookupPath":"https://firebasestorage.googleapis.com/v0/b/promptplusai.appspot.com/o/projectLookups%2FHlm0AZ9mUCeWrMF6hI7SueVPbrq1%2Fcovid-sentencechunk-v3%2FbyDocument%2FDOC_ID_URIENCODED.json?alt=media","topK":10},{"useDefaultSession":true,"title":"Klyde Session"}]');

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
/*!*******************************!*\
  !*** ./src/service-worker.ts ***!
  \*******************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _extensioncommon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./extensioncommon */ "./src/extensioncommon.ts");
/* harmony import */ var _semanticcommon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./semanticcommon */ "./src/semanticcommon.ts");
/* harmony import */ var _metriccommon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./metriccommon */ "./src/metriccommon.ts");



chrome.runtime.onInstalled.addListener(async (reason) => {
    if (reason.reason === 'install') {
        await chrome.tabs.create({
            url: "https://unacog.com/klyde/"
        });
    }
    const extCommon = new _extensioncommon__WEBPACK_IMPORTED_MODULE_0__.AnalyzerExtensionCommon(chrome);
    extCommon.updateBrowserContextMenus();
});
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    function getPageDom() {
        return document.body.innerText;
    }
    if (info.menuItemId === 'hideAnalyzeInSelectionContextMenu') {
        chrome.sidePanel.open({ tabId: tab.id });
        await processAnalysisContextMenuAction(info.selectionText, tab.url);
    }
    else if (info.menuItemId === 'hideAnalyzeInPageContextMenu') {
        chrome.sidePanel.open({ tabId: tab.id });
        let scrapes = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: getPageDom,
        });
        processAnalysisContextMenuAction(scrapes[0].result, tab.url);
    }
    else if (info.menuItemId === 'showQueryInSelectionContextMenu') {
        new _extensioncommon__WEBPACK_IMPORTED_MODULE_0__.AnalyzerExtensionCommon(chrome).toggleExentionPage("main.html#semantic");
        processSemanticContextMenuAction(info.selectionText, tab.url);
    }
    else if (info.menuItemId === 'showQueryInPageContextMenu') {
        new _extensioncommon__WEBPACK_IMPORTED_MODULE_0__.AnalyzerExtensionCommon(chrome).toggleExentionPage("main.html#semantic");
        let scrapes = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: getPageDom,
        });
        await processSemanticContextMenuAction(scrapes[0].result, tab.url);
    }
});
chrome.action.onClicked.addListener((tab) => {
    new _extensioncommon__WEBPACK_IMPORTED_MODULE_0__.AnalyzerExtensionCommon(chrome).toggleSidePanel(tab);
});
chrome.runtime.onMessageExternal.addListener(async (request, sender, sendResponse) => {
    console.log(sender.tab ?
        "from a content script:" + sender.tab.url :
        "from the extension");
    if (request.sessionId) {
        await chrome.storage.local.set({
            sessionId: request.sessionId,
            apiToken: request.apiToken
        });
        sendResponse({ success: "key set" });
    }
    if (request.specialAction === 'openSidePanel') {
        chrome.sidePanel.open({ tabId: sender.tab.id });
    }
    if (request.specialAction === 'openMainPage') {
        new _extensioncommon__WEBPACK_IMPORTED_MODULE_0__.AnalyzerExtensionCommon(chrome).toggleExentionPage("main.html");
    }
    if (request.specialAction === 'serverScrapeUrl') {
        const options = request.options;
        const url = request.url;
        const m = new _metriccommon__WEBPACK_IMPORTED_MODULE_2__.MetricCommon(chrome);
        const response = await m.serverScrapeUrl(url, options);
        sendResponse({ success: "url scraped", response });
    }
    if (request.specialAction === 'runMetricAnalysis') {
        const m = new _metriccommon__WEBPACK_IMPORTED_MODULE_2__.MetricCommon(chrome);
        const ext = new _extensioncommon__WEBPACK_IMPORTED_MODULE_0__.AnalyzerExtensionCommon(chrome);
        // const activeTab = await chrome.tabs.getCurrent();
        const scrapeResults = await m.scrapeBulkUrl({
            scrape: "server scrape",
            url: request.url,
            options: '',
        }, null);
        let text = '';
        if (scrapeResults && scrapeResults.text)
            text = scrapeResults.text;
        text = text.slice(0, await ext.getEmbeddingCharacterLimit());
        const results = await m.runAnalysisPrompts(text, request.url, null, request.promptSet, false, request.title);
        sendResponse({ success: "analysis run", results });
    }
});
async function processAnalysisContextMenuAction(text, url) {
    const metricCommon = new _metriccommon__WEBPACK_IMPORTED_MODULE_2__.MetricCommon(chrome);
    const extCommon = new _extensioncommon__WEBPACK_IMPORTED_MODULE_0__.AnalyzerExtensionCommon(chrome);
    let isAlreadyRunning = await metricCommon.setMetricsRunning(true);
    if (isAlreadyRunning)
        return;
    text = text.slice(0, await extCommon.getEmbeddingCharacterLimit());
    await chrome.storage.local.set({
        sidePanelScrapeContent: text,
        sidePanelSource: 'scrape',
        sidePanelUrlSource: url,
        sidePanelScrapeType: "cache"
    });
    await metricCommon.runAnalysisPrompts(text, url);
}
async function processSemanticContextMenuAction(text, url) {
    const semanticCommon = new _semanticcommon__WEBPACK_IMPORTED_MODULE_1__.SemanticCommon(chrome);
    const extCommon = new _extensioncommon__WEBPACK_IMPORTED_MODULE_0__.AnalyzerExtensionCommon(chrome);
    let isAlreadyRunning = await semanticCommon.setSemanticRunning(true);
    if (isAlreadyRunning)
        return;
    text = text.slice(0, await extCommon.getEmbeddingCharacterLimit());
    await chrome.storage.local.set({
        semanticQueryText: text,
        semanticUrlSource: url,
        semanticScrapeType: "cache"
    });
    let selectedSemanticSource = await semanticCommon.getSelectedSemanticSource();
    await semanticCommon.selectSemanticSource(selectedSemanticSource, true);
    await semanticCommon.semanticQuery();
}

})();

/******/ })()
;
//# sourceMappingURL=service-worker.js.map