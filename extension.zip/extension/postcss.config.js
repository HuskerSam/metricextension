module.exports = {
    plugins: {
        "postcss-import": {}, // <= Add this
        tailwindcss: {},
        autoprefixer: {}
    }
}